import discord
from discord.ext import commands
import datetime
import os
import requests
import math
import asyncio
import pymongo
import asyncio
import colorama 
from colorama import Fore, Style
#from discord.ext.commands.errors import InvalidEndOfQuotedStringError
def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")


def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)
class Emote(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Emote" + Fore.RESET)

    @commands.guild_only()
    @commands.group(aliases=['e', 'em','emote'])
    @blacklist_check()
    @commands.has_permissions(manage_emojis=True)
    async def emoji(self, ctx):
     if ctx.invoked_subcommand is None:
         em = discord.Embed(title="Command: emoji", description="manage server emojis", color=self.color, timestamp=ctx.message.created_at)
         em.add_field(name="Sub Commands", value="```,emoji add\n,emoji enlarge\n,emoji list\n,emoji remove```", inline=False)
         em.add_field(name="Aliases", value="e, em, emote")
         em.add_field(name="Permissions", value="Manage Emojis")
         em.add_field(name="Arguments", value="Subcommand, Emoji")
         em.add_field(name="Command Usage", value="```Syntax: ,emoji [subcommand] [emoji]\nExample: ,emoji add :exit:```", inline=False)
         em.set_author(name="azure help", icon_url=ctx.author.avatar_url)
         em.set_footer(text="Command Module: Emoji")
         await ctx.send(embed=em)
         print('emote cmd used') 

    @emoji.command()
    @blacklist_check()
    @commands.guild_only()
    async def enlarge(self, ctx, emoji = None): 
      if emoji == None:
        await ctx.send(f':thumbsdown: - please provide a valid emoji to enlarge.')
        return
      if emoji[0] == '<':
        name = emoji.split(':')[1]
        emoji_name = emoji.split(':')[2][:-1]
        anim = emoji.split(':')[0]
        if anim == '<a':
            url = f'https://cdn.discordapp.com/emojis/{emoji_name}.gif'
        else:
            url = f'https://cdn.discordapp.com/emojis/{emoji_name}.png'
      else:
        await ctx.send(embed=discord.Embed(description="unable to use that emoji, make sure you're using a unicode emoji or one from this server", color=self.color))
        return
      await ctx.send(f'{url}')

    
    @commands.guild_only()
    @blacklist_check()
    @emoji.command()
    async def list(self, ctx):
        msg = ""
        for x in ctx.guild.emojis:
            if x.animated:
                msg += "<a:{}:{}> ".format(x.name, x.id)
            else:
                msg += "<:{}:{}> ".format(x.name, x.id)
        if msg == "":
            await ctx.send(f'there arent any emotes in this guild!')
            return
        else:
            i = 0 
            n = 2000
            for x in range(math.ceil(len(msg)/2000)):
                while msg[n-1:n] != " ":
                    n -= 1
                s=discord.Embed( color=self.color, description=msg[i:n])
                i += n
                n += n
                if i <= 2000:
                    s.set_author(name="{} Emojis".format(ctx.guild.name), icon_url=ctx.guild.icon_url)
                await ctx.send(embed=s)


    @commands.guild_only()
    @emoji.command()
    @blacklist_check()
    @commands.has_permissions(manage_emojis=True)
    async def add(self, ctx, emote = None):
     if emote == None:
        await ctx.send(f'witch emote would you like me to add?')
        return
     try:
        if emote[0] == '<':
            name = emote.split(':')[1]
            emoji_name = emote.split(':')[2][:-1]
            anim = emote.split(':')[0]
            if anim == '<a':
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.gif'
            else:
                url = f'https://cdn.discordapp.com/emojis/{emoji_name}.png'
            try:
                response = requests.get(url) 
                img = response.content
                emote = await ctx.guild.create_custom_emoji(name=name, image=img)
                await ctx.send(embed=discord.Embed(description=f'<:approve:906649360396353567> Added **emoji** [{emote.name}]({url}) to **{ctx.guild.name}**',color=self.good))
            except Exception as e:
                em = discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: Error, \n||{e}||", color=discord.Colour.from_rgb(255,172,28))
                await ctx.send(embed= em)
                return
        else:
            await ctx.send(f':thumbsdown: - please provide a valid emoji to add.')
            return
     except Exception as e:
        em = discord.Embed(description=f"{e}", color=discord.Color.random())
        await ctx.send(embed= em)
        return

    @emoji.command()
    @commands.bot_has_permissions(manage_emojis=True)
    @commands.has_permissions(manage_emojis=True)
    async def remove(self, ctx, emote : discord.Emoji = None):
     if emote == None:
        await ctx.send(f':thumbsdown: - please provide a valid emoji to delete.')
        return
        
     await ctx.send(embed=discord.Embed(description=f'<:approve:906649360396353567> Deleted **emoji** [{emote.name}]({emote.url}) from **{ctx.guild.name}**',color=self.good))
     await emote.delete()
     return


def setup(bot):
    bot.add_cog(Emote(bot))