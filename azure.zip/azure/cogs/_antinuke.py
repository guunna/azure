import nextcord as discord
import shelve, asyncio, datetime, json
from nextcord.ext import commands

success = "<:icons_Correct:916416152505286717>"
fail = "<:no:916416210915184660>"
async def keep_db_open():
	while True:
		await asyncio.sleep(0.1)
		global db
		db = shelve.open('./data/whitelisted') 

async def keep_db2_open():
	while True:
		await asyncio.sleep(0.1)
		global db2
		db2 = shelve.open('./data/admins')

def is_server_owner(ctx):
    return ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292


class antinuke(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.color = discord.Colour.from_rgb(105,145,157)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        self.good = discord.Colour.from_rgb(164, 235, 120)
    @commands.Cog.listener()
    async def on_ready(self):
      self.client.loop.create_task(keep_db_open())
      self.client.loop.create_task(keep_db2_open())
    
        
    @commands.guild_only()
    @commands.group(aliases=['aw','an', 'antiwizz'])
    @commands.has_permissions()
    async def antinuke(self, ctx):
     if ctx.invoked_subcommand is None:
            embed = discord.Embed(title=f"Command: ,antinuke", description=f"configurable anti nuke/wizz to limit bans, kicks, channel deletions, and role changes/updates with customizable limits", color=self.colour, timestamp=ctx.message.created_at)
            embed.add_field(name=f"Sub Commands", value=f"```,antinuke whitelist\n,antinuke unwhitelist\n,antinuke settings\n,antinuke permit\n,antinuke unpermit\n,antinuke permitted```", inline=False)
            embed.add_field(name="Aliases", value="an, antiwizz, aw")
            embed.add_field(name="Permissions", value="Guild Owner")
            embed.add_field(name="Arguments", value="Subcommand, Member")
            embed.add_field(name="Command Usage", value="```Syntax: ,antinuke [subcommand] <member>\nExample: ,antinuke whitelist @forge```", inline=False)
            embed.set_author(name="azure help", icon_url=ctx.author.avatar_url)
            embed.set_footer(text="Command Module: Antinuke")
            await ctx.send(embed=embed)
            print('antinuke cmd used') 
    
    @antinuke.command(aliases=["wl"])
    @commands.check(is_server_owner)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def whitelist(self, ctx, user: discord.Member = None):
        if user is None:
            #eee = discord.Embed(color=self.colour, description=f"{fail} | specify a user/bot to whitelist")
            await ctx.send(f'give a user to **whitelist**')
            return
        if str(ctx.guild.id) not in db:
            db[str(ctx.guild.id)] = []
        if str(user.id) not in db[str(ctx.guild.id)]:
            copy = db[str(ctx.guild.id)]
            copy.append(str(user.id))
            db[str(ctx.guild.id)] = copy
            db.close()
        else:
            #e = discord.Embed(color=self.colour, description="{} | {} is already whitelisted")
            await ctx.send(f'**{user}** is already whitelisted :thumbsdown:')
            return
        ee = discord.Embed(color=self.colour,
                       description=f"{user.mention} is now whitelisted")
        await ctx.send(embed=ee)
        print(f"{user} has been added to whitelist")

    @antinuke.command(aliases=["unwl"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.check(is_server_owner)
    async def unwhitelist(self, ctx, user: discord.Member = None):
        if user is None:
            eee = discord.Embed(color=0xff4d4d, description=f"{fail} | specify a user/bot to unwhitelist")
            await ctx.message.reply(embed=eee, mention_author=False)
            return
        if str(user.id) not in db[str(ctx.guild.id)]:
            e = discord.Embed(color=0xff4d4d, description=f"{fail} | that user isn't whitelisted")
            await ctx.message.reply(embed=e, mention_author=False)
        else:
            copy = db[str(ctx.guild.id)]
            copy.remove(str(user.id))
            db[str(ctx.guild.id)] = copy
            db.close()
            ee = discord.Embed(color=self.colour, description=f"{user.mention} has been unwhitelisted!")
            await ctx.sned(embed=ee)

    @antinuke.command(aliases=["wld"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def settings(self, ctx):
        if str(ctx.author.id) in db[str(ctx.guild.id)]:
            try:
                embed = discord.Embed(title="status: **enabled** <:check:920426734875205682>", color=self.color)
                embed.description = "\n".join(
                    str(self.client.get_user(id=int(user_id))) for user_id in db[str(ctx.guild.id)])
                embed.set_footer(text="all of a user's roles will be removed when a limit is hit")
                #embed.set_thumbnail(url=ctx.bot.user.avatar_url)
                await ctx.send(embed=embed)
            except KeyError:
                e = discord.Embed(color=self.bad,
                                  description=f"<:deny:903751730880213062> no users/bots are currently whitelisted")
                await ctx.send(embed=e)
        else:
            ee = discord.Embed(color=self.bad,
                           description=f"<:deny:903751730880213062> only whitelisted users can view the whitelist")
            await ctx.message.reply(embed=ee, mention_author=False)

    @antinuke.command(aliases=["clearwld", "clearwl"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.check(is_server_owner)
    async def clearwhitelist(self, ctx):
        if db[str(ctx.guild.id)] == []:
            e = discord.Embed(color=self.bad,
                              description=f"<:deny:903751730880213062> no users/bots are currently whitelisted")
            await ctx.send(embed=e)
        else:
            copy = db[str(ctx.guild.id)]
            copy.clear()
            db[str(ctx.guild.id)] = copy
            db.close()
            ee = discord.Embed(color=self.good,
                              description=f"<:approve:906649360396353567> whitelist cleared for **{ctx.guild.name}**")
            await ctx.message.reply(embed=ee, mention_author=False)

    @antinuke.command()
    @commands.check(is_server_owner)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def permit(self, ctx, user: discord.Member = None):
        if user is None:
            eee = discord.Embed(color=self.bad, description=f"<:deny:903751730880213062> specify a user to grant administrator")
            await ctx.send(embed=eee)
            return
        if str(ctx.guild.id) not in db2:
            db2[str(ctx.guild.id)] = []
        if str(user.id) not in db2[str(ctx.guild.id)]:
            copy = db2[str(ctx.guild.id)]
            copy.append(str(user.id))
            db2[str(ctx.guild.id)] = copy
            db2.close()
        else:
            e = discord.Embed(color=self.bad, description=f"<:deny:903751730880213062> {user.mention} is already a administrator")
            await ctx.message.reply(embed=e, mention_author=False)
            return
        ee = discord.Embed(color=self.good,
                       description=f"<:approve:906649360396353567> {user.mention}is now antinuke admin")
        await ctx.send(embed=ee)

    @antinuke.command()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.check(is_server_owner)
    async def unpermit(self, ctx, user: discord.Member = None):
        if user is None:
            eee = discord.Embed(color=self.bad, description=f"<:deny:903751730880213062> specify a user to remove administrator")
            await ctx.send(embed=ee)
            return
        if str(user.id) not in db2[str(ctx.guild.id)]:
            e = discord.Embed(color=self.bad, description=f"<:deny:903751730880213062> that user isn't a administrator")
            await ctx.send(embed=e)
        else:
            copy = db2[str(ctx.guild.id)]
            copy.remove(str(user.id))
            db2[str(ctx.guild.id)] = copy
            db2.close()
            ee = discord.Embed(color=self.good, description=f"<:approve:906649360396353567> {user.mention} is no longer antinuke admin")
            await ctx.send(embed=ee)

    @antinuke.command()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.check(is_server_owner)
    async def permitted(self, ctx):
        if str(ctx.author.id) in db2[str(ctx.guild.id)]:
            try:
                embed = discord.Embed(title="Admin users:", color=self.color)
                embed.description = "\n".join(
                    str(self.client.get_user(id=int(user_id))) for user_id in db2[str(ctx.guild.id)])
                embed.set_footer(text="these users are able to configure azure anti module")
                #embed.set_thumbnail(url=ctx.bot.user.avatar_url)
                await ctx.send(embed=embed)
            except KeyError:
                e = discord.Embed(color=self.bad,
                                  description=f"<:deny:903751730880213062> no users are currently administrators")
                await ctx.send(embed=e)
        else:
            ee = discord.Embed(color=self.bad,
                           description=f"<:deny:903751730880213062> only whitelisted users can view the administrators list")
            await ctx.send(embed=ee)

    @antinuke.command()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.check(is_server_owner)
    async def clearpermitted(self, ctx):
        if db2[str(ctx.guild.id)] == []:
            e = discord.Embed(color=self.bad,
                              description=f"<:deny:903751730880213062>  no users are currently administrators")
            await ctx.send(embed=e)
        else:
            copy = db2[str(ctx.guild.id)]
            copy.clear()
            db2[str(ctx.guild.id)] = copy
            db2.close()
            ee = discord.Embed(color=self.good,
                              description=f"<:approve:906649360396353567> administrator list cleared for **{ctx.guild.name}**")
            await ctx.send(embed=ee)
            
            def embed(content):
              embed =  discord.Embed(description=content, color=self.color)
              return embed

def setup(client):
  client.add_cog(antinuke(client))