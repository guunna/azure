import discord
from discord.ext import commands
import datetime
import os
import requests
import math
import asyncio
import pymongo
import asyncio
import time
import colorama 
from colorama import Fore, Style
mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")
def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class Jail(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Jail" + Fore.RESET)
    
    @commands.command(name="jail", description="Jails a user", usage="jail <user>")
    @blacklist_check()
    @commands.has_permissions(administrator=True)
    async def jail(self, ctx, member: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        if not role:
            await ctx.guild.create_role(name="jailed")
        jail = discord.utils.get(ctx.guild.text_channels, name="jail")
        if not jail:
            try:
                overwrites = {
                    ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False, send_messages=False),
                    ctx.guild.me: discord.PermissionOverwrite(read_messages=True)
                }            
                jail = await ctx.guild.create_text_channel("jail", overwrites=overwrites)
                await ctx.send(f"created jail channel {jail.metion} :thumbsup:")
            except discord.Forbidden:
                return await ctx.send('unable to create jail channel `missing permissions` :thumbsdown:')

        for channel in ctx.guild.channels:
            if channel.name == "jail":
                perms = channel.overwrites_for(member)
                perms.send_messages = True
                perms.read_messages = True
                await channel.set_permissions(member, overwrite=perms)
            else:
                perms = channel.overwrites_for(member)
                perms.send_messages = False
                perms.read_messages = False
                perms.view_channel = False
                await channel.set_permissions(member, overwrite=perms)

        role = discord.utils.get(ctx.guild.roles, name="jailed")
        await member.add_roles(role)

        await jail.send(content=member.mention, embed=discord.Embed(title="", description="you been put in jail wait until your free", color=self.colour))
        await ctx.send(f'**{member}** has been jailed :thumbsup:')
        #await ctx.send(embed=discord.Embed(title="", description=f"<:successful:875765462607228978> **successfully jailed** {member.mention}", color=self.colour))
        await member.send(embed=discord.Embed(title="jailed", description=f"reason:N/A\nmoderator: {ctx.author}\nServer: {ctx.guild.name}", color=self.colour))
    
    @commands.command(name="unjail", description="Unjails a user", usage="unjail <user>",  aliases=["free"])
    @blacklist_check()
    @commands.has_permissions(administrator=True)
    async def unjail(self, ctx, member: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        for channel in ctx.guild.channels:
            if channel.name == "jail":
                perms = channel.overwrites_for(member)
                perms.send_messages = None
                perms.read_messages = None
                await channel.set_permissions(member, overwrite=perms)
            else:
                perms = channel.overwrites_for(member)
                perms.send_messages = None
                perms.read_messages = None
                perms.view_channel = None
                await channel.set_permissions(member, overwrite=perms)
        role = discord.utils.get(ctx.guild.roles, name="jailed")
        await member.remove_roles(role)
        await ctx.send(f"**{member}** has been unjailed :thumbsup:")

        #await ctx.send(embed=discord.Embed(title="", description=f"**{member.mention}** has been unjailed**", color=self.colour))
        await member.send(embed=discord.Embed(title="", description=f"**you have been unjailed in** `{ctx.guild.name}` by `{ctx.author.name}`", color=self.colour))

def setup(bot):
    bot.add_cog(Jail(bot))