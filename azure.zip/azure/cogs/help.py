import discord
from discord.ext import commands
import pymongo
import asyncio
import colorama 
from colorama import Fore
from discord_components import * 
def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292
#check cord fam
class help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot 
        DiscordComponents(bot)
        self.color = discord.Colour.from_rgb(105,145,157)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Help" + Fore.RESET)
    
    @commands.command()
    async def pages(self, ctx):
      if ctx.author.id == 717206196091617292:
        current = 0
        a = discord.Embed(title=f"Launch Pad", description=f"For regular commands use `,help [command]`\n\n**Want Azure in your server**\njoin the [support server]()\n\n:newspaper: **Latest News - December 19th 2021**\nadded welcome and revamped bot",color=self.color)
        a.set_author(name="azure help", icon_url=ctx.author.avatar_url)
        b = discord.Embed(title="help — configuration", description=f"commands related to **configuration**", color=self.color)
        b.add_field(name="welcome commands", value=",welcome \n └ message - set the greet message when users join \n └ channel - set the greet channel where messages will be sent\n,goodbye \n └ message - set the leave message when users leave \n └ channel - set the leave channel where messages will be sent", inline=False)
        b.add_field(name="antinuke commands", value=",antinuke \n└ settings - shows the antinuke settings for the server \n └ toggle - allows you to enabled/disable the antinuke modules for the server \n └ punishment - changes the punishment for when a limit is succeeded \n └ whitelist - allow's the user not to get punished during a server action\n└ removes the user from not being punished", inline=False)
        b.add_field(name="autorole commands", value=",autorole \n └ add - sets role memebers will get after joining", inline=False)
        b.set_author(name="azure help", icon_url=ctx.author.avatar_url)
        c = discord.Embed(title="help — information", description=f"commands related to **information**", color=self.color)
        c.add_field(name="info commands", value=",botinfo - displays info about azure\n,butreport - reports bugs you see to developers\n,donate - help us out with a few bucks\n,feedback - give feedback on your experience of azure\n,help - displays commands\n,invite - sends invite of azure\n,ping - displays bot latency\n,support - sends invite to azures support server\n,uptime - displays how long auzre been running\n,version - displaus azures current version", inline=False)
        c.set_author(name="azure help", icon_url=ctx.author.avatar_url)
        d = discord.Embed(title="help — giveaway", description="commands related to **giveaway**", color=self.color)
        d.add_field(name="giveaway commands", value=",start - starts giveaway prosess\n,reroll - picks different winner", inline=False)


        paginationList = [a, b, c, d] 
        mainMessage = await ctx.send(
            embed = paginationList[current],
            components = [ #Use any button style you wish to :)
                [
                    Button(
                        label = "<",
                        id = "back",
                        style = ButtonStyle.blue,
                        #emoji="<:left:904917144645546004>"
                    ),
                    Button(
                    label = f"Page {int(paginationList.index(paginationList[current])) + 1}/{len(paginationList)}",
                    id = "cur",
                    style = ButtonStyle.grey,
                    disabled = True
                    ),
                    Button(
                        label = ">",
                        id = "front",
                        style = ButtonStyle.blue,
                        #emoji="<:right:904917173548494900>"
                    )
                ]
            ]
        )
        while True:
            try:
                interaction = await self.bot.wait_for(
                    "button_click",
                    check = lambda i: i.component.id in ["back", "front"],
                    timeout = 15.0
                )
                if interaction.component.id == "back":
                    current -= 1
                elif interaction.component.id == "front":
                    current += 1
                if current == len(paginationList):
                    current = 0
                elif current < 0:
                    current = len(paginationList) - 1

                await interaction.respond(
                    type = 7,
                     embed = paginationList[current],
                     components = [
                        [
                         Button(
                            label = "<",
                            id = "back",
                            style = ButtonStyle.blue
                        ),
                        Button(
                            label = f"Page {int(paginationList.index(paginationList[current])) + 1}/{len(paginationList)}",
                            id = "cur",
                            style = ButtonStyle.grey,
                            disabled = True
                        ),
                        Button(
                            label = ">",
                            id = "front",
                            style = ButtonStyle.blue
                        )
                    ]
                ]
            )
            except asyncio.TimeoutError:
              await mainMessage.edit(
                components = [
                    [
                        Button(
                            label = "<",
                            id = "back",
                            style = ButtonStyle.blue,
                            disabled = True
                        ),
                        Button(
                            label = f"Page {int(paginationList.index(paginationList[current])) + 1}/{len(paginationList)}",
                            id = "cur",
                            style = ButtonStyle.grey,
                            disabled = True
                        ),
                        Button(
                            label = ">",
                            id = "front",
                            style = ButtonStyle.blue,
                            disabled = True
                        )
                    ]
                ]
            )
            break
        else:
          return
    



def setup(client):
    client.add_cog(help(client))