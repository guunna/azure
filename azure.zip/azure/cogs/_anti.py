import discord
import shelve, json, asyncio, datetime
from discord.ext import commands

async def keep_db_open():
	while True:
		await asyncio.sleep(0)
		global db
		db = shelve.open('./data/whitelisted')

class antievents(commands.Cog):
    def __init__(self, client):
        self.client = client
        print(f"{Fore.CYAN}[Status] Cog Loaded: Anti" + Fore.RESET)

    @commands.Cog.listener()
    async def on_ready(self):
      self.client.loop.create_task(keep_db_open())

    @commands.Cog.listener()
    async def on_member_ban(self, guild, member):
        i = await guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.ban).flatten()
        i = i[0]
        try:
            if str(i.user.id) in db[str(i.guild.id)]:
                return
            
            if i.user.id in [717206196091617292]:
                    return

            await i.user.ban(reason=f"Azure - Banning Members")
            return
        except KeyError:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        async for i in member.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.kick):
            try:
                if str(i.user.id) in db[str(member.guild.id)]:
                    return
    
                if i.target.id == member.id:
                    await i.user.ban(reason=f"Azure - Kicking Members")
                return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_member_join(self, member):
      if member.bot:
        async for i in member.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.bot_add):
            try:
                if str(i.user.id) in db[str(member.guild.id)]:
                    return

                await member.ban(reason="Azure - Bot Added By Unwhitelisted User")
                await i.user.kick(reason="Azure - Adding Bots")
                return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_member_prune(self, guild, member):
        async for i in guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.member_prune):
            try:
                if str(i.user.id) in db[str(member.guild.id)]:
                    return
                        
                if i.target.id == member.id:
                    await member.ban(reason="Azure - Pruning Members")
                    return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        async for i in before.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.guild_update):
            try:
                if str(i.user.id) in db[str(before.id)]:
                    return
                
                if i.after.vanity_url_code != i.before.vanity_url_code:
                    await after.edit(vanity_code = i.before.vanity_url_code)
                    await i.user.ban(reason="Azure - Changing Vanity")
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        async for i in channel.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes=1), action=discord.AuditLogAction.channel_create):
            try:
                if str(i.user.id) in db[str(channel.guild.id)]:
                    return

                await i.user.ban(reason="Azure - Creating Channels")
                await channel.delete(reason="Azure - non-whitelisted user channel")
                return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        async for i in channel.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes=1), action=discord.AuditLogAction.channel_delete):
            try:
                if str(i.user.id) in db[str(channel.guild.id)]:
                    return

                await i.user.ban(reason="Azure - Deleting Channels")
                return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        try:
            on = ""
            with open('./data/toggle.json') as f:
                toggles = json.load(f)
                async for i in role.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes=1), action=discord.AuditLogAction.role_delete):
                    if on in toggles[str(role.guild.id)]:
                        return
                    if str(i.user.id) in db[str(role.guild.id)]:
                        return

                    await role.guild.ban(i.user, reason="Azure - Deleting Roles")
                    return
        except KeyError:
            pass

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if after.guild_permissions.administrator and not before.guild_permissions.administrator:
         async for i in after.guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes=1), action=discord.AuditLogAction.member_role_update):
            try:
                if str(i.user.id) in db[str(after.guild.id)]:
                    return

                await after.guild.ban(i.user, reason=f'Azure - Giving Members Admin')
                return
            except KeyError:
                pass

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        perms = discord.Permissions
        async for i in after.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_update):
            try:
                if str(i.user.id) in db[str(after.guild.id)]:
                    return

                perm = perms()
                perm.update(administrator = False)
                if not before.permissions.administrator and after.permissions.administrator:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with administrator permissions')
                    await after.edit(permissions=perm)  
                    return

                perm = perms()
                perm.update(ban_members = False)
                if not before.permissions.ban_members and after.permissions.ban_members:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with ban permissions')
                    await after.edit(permissions=perm)  
                    return
                
                perm = perms()
                perm.update(kick_member = False)
                if not before.permissions.kick_members and after.permissions.kick_members:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with kick permissions')
                    await after.edit(permissions=perm)
                    return

                perm = perms()
                perm.update(manage_guild = False)
                if not before.permissions.manage_guild and after.permissions.manage_guild:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with manage guild permissions')
                    await after.edit(permissions=perm)  
                    return    

                perm = perms()
                perm.update(manage_channels = False)
                if not before.permissions.manage_channels and after.permissions.manage_channels:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with manage channel permissions')
                    await after.edit(permissions=perm)  
                    return

                perm = perms()
                perm.update(manage_roles = False)
                if not before.permissions.manage_roles and after.permissions.manage_roles:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with manage role permissions')
                    await after.edit(permissions=perm)  
                    return    

                perm = perms()
                perm.update(manage_webhooks = False)
                if not before.permissions.manage_webhooks and after.permissions.manage_webhooks:
                    await after.guild.ban(i.user, reason=f'Azure - updated {after.name} with webhook permissions')
                    await after.edit(permissions=perm)  
                    return
            except KeyError:
                pass

def setup(client):
  client.add_cog(antievents(client))