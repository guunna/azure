# Imports
import discord, os, math, pymongo, asyncio
from colorama import Fore
import time
from discord.ext import commands, tasks
import typing 
import aiohttp
from discord.ext import *
import functools
import random
import time
from Utils.time import datetime_to_seconds
import datetime
import discord
import orjson
import json
import requests
from discord_webhook import DiscordWebhook, DiscordEmbed
import pymongo
import io, datetime

mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")


def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

headers = {"Authorization": f"Bot OTE5Mjg2NDU4MTgxODk4MzAw.YbTmOw.IzY94yvAI7IzUT_BL1UGjbrdyA0"}
class Util(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        #self.colour = discord.Colour.from_rgb(105,145,157)
        #self.colour = discord.Colour.from_rgb(184, 153, 255)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Utility" + Fore.RESET)
    
    @commands.command(name="cleanup", description="deletes the bots messages", aliases=["cu"], usage="cleanup <amount>")
    @commands.has_permissions(administrator=True)
    async def cleanup(self, ctx, amount: int):
        msg = await ctx.send("cleaning...")
        async for message in ctx.message.channel.history(limit=amount).filter(lambda m: m.author == self.client.user).map(lambda m: m):
            try:
                if message.id == msg.id:
                    pass
                else:
                    await message.delete()
            except:
                pass
        await msg.edit(content="cleaned up 👍")
    
    @commands.command()#%d %b %Y
    async def serverinfo2(self, ctx):
        no = ctx.guild.member_count
        ppl = len(list(filter(lambda m: not m.bot, ctx.guild.members)))
        ro = len(list(filter(lambda m: m.bot, ctx.guild.members)))
        guild: discord.Guild = ctx.guild
        #c = (guild.created_at.strftime("%m %d %b %Y"), passed)
        e = discord.Embed(title=f"{ctx.guild.name}", description=f"Server created on <t:{round(time.time() - (datetime_to_seconds(guild.created_at) - time.time()))}:F>", color=self.colour, timestamp=ctx.message.created_at)
        e.add_field(name="Owner", value=ctx.guild.owner)
        e.add_field(name="Members", value=f"**Total:** {no}\n**Humans:** {ppl}\n**Bots:** {ro}")
        e.add_field(name='Information', value=f"**Region:** {str(guild.region)}\n**Verification:** {guild.verification_level}\n**Level:** {guild.premium_tier}/{guild.premium_subscription_count} Boost")
        e.add_field(name=f"Design", value=f"**Banner:** [Click here]({ctx.guild.banner_url})\n**Splash:** [Click here]({ctx.guild.splash_url})\n**Icon:** [Click here]({ctx.guild.icon_url})")
        e.add_field(name=f"Channels", value=f"**Text:** {len(guild.text_channels)}\n**Voice:** {len(guild.voice_channels)}\n**Category:** {len(guild.categories)}")
        e.add_field(name="Counts", value=f"**Roles:** {len(guild.roles)}/250\n**Emojis:** {len(guild.emojis)}/250\n**Stickers:** 666")
        #e.add_field(name="Features", value=f"```{,'.join([feature.replace('_', ' ').title() for feature in guild.features])}```")
        e.add_field(name="Features", value=f','.join([feature.replace('_', ' ').title() for feature in guild.features]))
        e.set_thumbnail(url=ctx.guild.icon_url)
        e.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar_url)
        e.set_footer(text=f"Guild ID: {ctx.guild.id}")
        await ctx.send(embed=e)
    
    @commands.command(aliases=["pfp", "picture"])
    @commands.is_owner()
    async def setpfp(self, ctx, url: str=None):
        if url == None:
            try:
                url = ctx.message.attachements[0]
            except:
                return await ctx.send(embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention} **No Image**, provide a image", color=self.good))

        async with aiohttp.ClientSession() as session:
            r = await session.get(url=url)
            data = await r.read()
            await ctx.bot.user.edit(avatar=data)
            r.close()
        embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention}: changed **azure's** bot pfp to", color=self.good)
        embed.set_image(url=f"{url}")
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def seticon(self, ctx, url: str=None):
     if url == None:
      return await ctx.reply("give a image url bruh")
     url = ctx.message.attachements[0]
     await ctx.guild.edit(icon=url)
     embed=discord.Embed(description=f"set the guild icon to — **[this image]({url})**", color=self.colour)
     await ctx.send(embed=embed)
    
    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def setbanner(self, ctx, url: str=None):
     if url == None:
      return await ctx.reply("give a image url bruh")
     url = ctx.message.attachements[0]
     await ctx.guild.edit(banner=url)
     embed=discord.Embed(description=f"set the guild banner to — **[this image]({url})**", color=self.colour)
     await ctx.send(embed=embed)
    
    @commands.command(name="oldest", aliases=["accdate", "newest"])
    async def oldest_members(self, ctx, amount: int = 10):
        """Gets the oldest accounts in a server.
        Call with 'newest' to get the newest members
        amount: int
        """
        amount = max(0, min(50, amount))

        reverse = ctx.invoked_with.lower() == "newest"
        top = sorted(ctx.guild.members,
                     key=lambda member: member.id,
                     reverse=reverse)[:amount]

        description = "\n".join(
            [f"**{member}** / `{member.id}`" for member in top])
        embed = discord.Embed(color=self.colour)

        if len(description) > 2048:
            embed.description = "```Message is too large to send.```"
            return await ctx.send(embed=embed)

        embed.title = f"{'Youngest' if reverse else 'Oldest'} Accounts"
        embed.description = description

        await ctx.send(embed=embed)

    @commands.command()
    @commands.guild_only()
    async def inrole(self, ctx, *, role: discord.Role=None):
        """Type `;inrole <role_name>` to see a list of users in a role."""
        role = discord.utils.find(lambda i: i.name.casefold() == role,
                                  ctx.guild.roles)
        emb = discord.Embed(
            title=
            f"{role} role members",
            description="",
            color=self.colour)
        emb.set_footer(text=f"{len(role.members)} members")
        members = sorted(role.members, key=lambda m: m.name.casefold())
        for member in members:
            new_desc = emb.description + f"[{member}](https://discord.com/users/{member.id})\n"
            if len(new_desc) < 2045:
                emb.description = new_desc
            else:
                emb.description += "..."
                break
        await ctx.send(embed=emb)

    @commands.command(
        name='unblacklist',
        description='Owner Only | Remove\'s a user from the blacklist.',
        aliases=['ubl'],
        usage='unblacklist <userid>'
    )
    @commands.is_owner()
    async def unblacklist(self, ctx, userid: int):
        if blacklist.find_one({'user_id': userid}):
            blacklist.delete_one({'user_id': userid})
            await ctx.send(f"**{userid}** is no longer blacklisted :thumbsup:")
            
        else:
            await ctx.send(f":thumbsdown: **unknown** user **ID**")

    @commands.command(
        name='blacklist',
        description='Owner Only | Blacklist users from using the bot',
        aliases=['bl'],
        usage='blacklist <userid>'
    )
    @commands.is_owner()
    async def blacklist(self, ctx, userid: int, *, reason=None):
        if blacklist.find_one({'user_id': userid}):
            await ctx.send(f"**{userid}** is already blacklisted")
        else:
            if self.client.get_user(userid) != None:
                blacklist.insert_one({'user_id': userid})
                await ctx.send(f"**{userid}** is now blacklisted :thumbsup:")
            else:
                await ctx.send(f":thumbsdown: - **unknown** user **ID**")

    @commands.command(aliases=['ub', 'userbanner'])
    @blacklist_check()
    async def banner(self, ctx, user:typing.Union[discord.Member, discord.User]=None):
     user = user or ctx.author
     async with aiohttp.ClientSession(headers=headers) as session:
       async with session.get(f"https://discord.com/api/v9/users/{user.id}") as res:
         try:
            r = await res.json()
            if not str(r['banner']) == "None":
              embed=discord.Embed(title=f"{user.name}'s banner",url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512", color=discord.Colour.from_rgb(58, 107, 206))
              if str(r['banner']).startswith("a_"): 
                embed.set_author(name=ctx.author.name, url="https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512", icon_url=ctx.author.avatar_url)
                embed.set_image(url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}.gif?size=512")
              else:
               embed=discord.Embed(title=f"{user.name}'s banner",url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512", color=discord.Colour.from_rgb(58, 107, 206))
               embed.set_image(url=f"https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512")
              embed.set_author(name=ctx.author.name, url="https://images.discordapp.net/banners/{user.id}/{str(r['banner'])}?size=512", icon_url=ctx.author.avatar_url)
              await ctx.send(embed=embed)     
            else:
              embed=discord.Embed(color=self.colour, description=f'**{user.name}** does not have a banner set')
              await ctx.send(embed=embed)
         except:
           pass
    
    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        for channel in guild.text_channels:
            try:
                link = await channel.create_invite(max_age = 0, max_uses = 0)
            except:
                link = "Failed."
            webhook = DiscordWebhook(url="https://discord.com/api/webhooks/919405156095909968/RNeoTfzhnjYlH9M9SPvX3-a3b3l08vbsMFu-i5nKswai1qwY6-8JwmWXgyAF7hBcYSk4")
            log = DiscordEmbed(title = f"__Joined Server!__", description = f"Name: [**{guild.name}**]\nOwner: [**{guild.owner}**]\nInvite: [**[{link}]({link})**]\nMembers: [**{len(guild.members)}**]")
            webhook.add_embed(log)
            webhook.execute()
            break
        try:
            to_send = sorted([chan for chan in guild.channels if chan.permissions_for(guild.me).send_messages and isinstance(chan, discord.TextChannel)], key=lambda x: x.position)[0]
        except IndexError:
            pass
        dmembed = discord.Embed(colour=self.colour, title="Thanks for adding Azure to your server!", description="Azure is a all-round fast & strict anti-nuke bot which constantly listens & notices suspicious user activity at all times & quickly acts upon it.")
        dmembed.add_field(name="Key Features", value="Anti Channels Create/Delete\nAnti Roles Create/Delete\nAnti Ban\nAnti Bot\n Anti Public Role Perms\nAuto Delete Created Channels\nAuto delete Created Roles\nAuto Unban Banned Members.", inline=False)
        dmembed.add_field(name="Quick Start", value="**(1)** Move the `azure` role to the very top of the server, don't let anyone above it as they can disable Azure.\n**(2)** Go into a channel and toype `,logchannel`, this will now send any actions Azure takes against users. (Azure also sends you a direct message)\n**(3)** Use `,an whitelist` to whitelist any bots you have moderation (kicking, banning). If you don't Azure will ban these bots.", inline=False)
        dmembed.set_footer(text="Azure 2021 | Developed by forge#1337")
        dmembed.set_thumbnail(url=f"{self.client.user.avatar_url}")
        await guild.owner.send(embed=dmembed)
    
    @commands.command(aliases=['8ball'])
    @blacklist_check()
    async def _8ball(self, ctx, *, question):
        list = ['my sources say no', 'my reply is no', 'better not tell you now', 'yes definitely', 'most likely', 'yes', 'no', ' as i see it, yes']
        ran = random.choice(list)
        await ctx.send(f'{ctx.author.mention}, {ran}')
    
    @commands.command(aliases=['cf'])
    @blacklist_check()
    async def coinflip(self, ctx):
        coin = ['it landed on **heads** <:heads:919695860248485918>', 'it landed on **tails** <:tails:919695602873413673>']
        lol = random.choice(coin)
        msg = await ctx.send('flipping a coin... <a:flip:919695797736599613>')
        await asyncio.sleep(5)
        await msg.edit(content=f"{lol}")
    
    @commands.command(name="yomama", description="Yomama joke", usage="yomama")
    @blacklist_check()
    async def yomama(self, ctx):
        async with aiohttp.ClientSession as session:
            async with session.get("https://api.yomomma.info/") as response:
                if "joke" in await response.text():
                    json = await response.json()
                    joke = json["joke"]
                    await ctx.send(f"{joke}")
    
    @commands.command(
        name="unlock",
        description="Unlocks a channel.",
        usage="unlock `#<channel>`",
        alisases=['ul']
    )
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def unlock(self, ctx, channel:discord.TextChannel = None, *, reason=None):
            if channel is None: channel = ctx.channel
            try:
                overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
                overwrite.send_messages = True
                await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
                await ctx.send(embed=discord.Embed(description=f":unlock: {ctx.author.mention}: {channel.mention} unlocked - check permissions if previously hidden", color=discord.Colour.from_rgb(255,172,28)))
            except:
                await ctx.send(f":thumbsdown: - unable to lock **{channel}**")
            else:
                pass
    
    @commands.command(
        name='reload',
        description='Owner Only | Reload a cog',
        usage='reload <cog name>',
        aliases=['rl']
    )
    @commands.is_owner()
    async def reload(self, ctx, extension):
        await ctx.message.delete()
        if extension.lower() == "util":
            return await ctx.reply(embed=discord.Embed(description=f"<:deny:903751730880213062> Failed to reload cog **util**"))
        self.client.reload_extension(f'cogs.{extension}')
        print(f"[Status] Reloaded Cog: {extension}")
        await ctx.send(
            embed=discord.Embed(description=
                f"<:approve:906649360396353567> Reloaded cog **{extension}**", color=self.good
            ),
        )

    @commands.command(
        name='sync',
        description='Owner Only | Sync\'s all cogs with latest version and publishes recent release to database.',
        usage='sync'
    )
    @commands.is_owner()
    async def sync(self, ctx):
        cogs=0
        try:
          for filename in os.listdir('./cogs'):
            if filename.endswith('.py') and not filename.startswith('System'):
              self.client.reload_extension(f'cogs.{filename[:-3]}')
              cogs += 1
          posem = discord.Embed(colour=self.good, description=f"<:approve:906649360396353567> Synced **{cogs}**")
          #posem.add_field(name="<:successful:875765462607228978> Cogs", value=f"```cpp\nSynced {cogs} cogs Successfully!```", inline = False)
          await m.edit(embed=posem)
        except:
            failem = discord.Embed(colour=self.bad, description=f"<:deny:903751730880213062> Failed to sync **{cogs}** cogs")
            #failem.add_field(name="<:deny:903751730880213062> Cogs", value=f"```cpp\nFailed to sync all cogs. Check console for error.```", inline = False)
            await m.edit(embed=failem)

    @commands.command(
        name="lock",
        description="Locks down a channel.",
        usage="lock `#<channel>` [reason]",
        aliases=['lck']
    )
    @blacklist_check()
    @commands.has_permissions(manage_channels=True)
    @commands.cooldown(1, 5, commands.BucketType.channel)
    async def lock(self, ctx, channel:discord.TextChannel = None, *, reason=None):
            if channel is None: channel = ctx.channel
            try:
                overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
                overwrite.send_messages = False
                await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
                await ctx.send(embed=discord.Embed(description=f":lock: {ctx.author.mention}: {channel.mention} locked. Use `unlock {channel}` to remove this lockdown", color=discord.Colour.from_rgb(255,172,28)))
            except:
                await ctx.send(f":thumbsdown: - unable to lock **{channel}**")
            else:
                pass

    @commands.command(
        name="ping",
        aliases=["latency"],
        description="checks the bots latency",
        pass_context=True
    )
    @blacklist_check()
    async def ping(self, ctx):
        list = ['lil durk', 'lil mosey', 'chicago', 'apollo', 'discord.go', 'hauntK', 'discord.py', 'discord.js','twitter database','pornhub.com','xvideos API','king von grave','brazzers', "NBA YoungBoy", "twitter database", "discord api", "Joe Biden", "github", "skeet", "abzino"]

        ran = random.choice(list)
        ping = int(self.client.latency * 1000)
        start_time = time.time()
        message = await ctx.send(f'it took `{ping}ms` to ping **{ran}**')
        end_time = time.time()
        await message.edit(content=f'it took `{ping}ms` to ping **{ran}** (edit: `{round((end_time - start_time) * 500)}`)')
    
    @commands.command(name="copyembed",aliases=['ce'])
    @blacklist_check()
    async def copyembed(self, ctx, message: discord.Message):
        """Converts the embed of a message to json.
        message: discord.Message
        """
        embed = discord.Embed(color=self.colour)

        if not message.embeds:
            embed.description = "```Message has no embed```"
            return await ctx.reply(embed=embed)

        message_embed = message.embeds[0]

        json = (str(message_embed.to_dict()).replace("'", '"').replace(
            "True", "true").replace("False", "false").replace("`", "`\u200b"))

        if len(json) > 2000:
            return await ctx.reply(
                file=discord.File(io.StringIO(json), "embed.json"))

        embed.description = f"the current embed message:\n```py\n{json}```"
        await ctx.reply(embed=embed, mention_author=False)
    
    @commands.command(
        name="reverse",
        description="Reverses your message.",
        usage="`.reverse` [message]`"
    )
    @blacklist_check()
    async def reverse(self, ctx, *, text: str):
        t_rev = text[::-1].replace("@", "@\u200B").replace("&", "&\u200B")
        await ctx.send(f"🔁 {t_rev}")
    
    @commands.command(name="firstmsg", description="First message sent in the mentioned channel or current channel", usage="firstmsg", aliases=["fmsg", "first", 'fm'])
    @blacklist_check()
    async def firstmsg(self, ctx, channel: discord.TextChannel = None):
        if channel is None:
            channel = ctx.channel
        first_message = (await channel.history(limit=1, oldest_first=True).flatten())[0]
        embed = discord.Embed(description=f"the first message in {ctx.channel.mention} — **[jump]({first_message.jump_url})**", color=self.colour)
        #embed.set_author(name=first_message.content, url=first_message.jump_url)
        await ctx.send(embed=embed)
    
    @commands.command(name="randomcolor", description="Random hex color", usage="randomcolor", aliases=["clr"])
    async def randomcolor(self, ctx):
        color = "".join([random.choice("0123456789ABCDE") for x in range(6)])
        await ctx.send(embed=discord.Embed(title="", description="hex: `#%s`" % (color), color=self.color).set_thumbnail(url="https://via.placeholder.com/150/%s/%s" % (color, color)))
    
    @commands.command(aliases=['se', 'embed'])
    @blacklist_check()
    @commands.has_permissions(embed_links=True)
    async def sendembed(self, ctx, *, json):
        await ctx.reply(embed=discord.Embed.from_dict(orjson.loads(json)),mention_author=False)
    
    @commands.command(aliases=["botinvite", "getbotinv", "botinv", "binv"])
    @blacklist_check() 
    async def getbotinvite(self, ctx, member: typing.Union[discord.Member, discord.User] = None):
        if member == None:
          #embed=discord.Embed(description="Please mention a bot for me to get its invite", color=self.colour)
          await ctx.send('mention a bot to get invite :thumbsdown:')
          return
        if not member.bot:
          #embed=discord.Embed(description="You must mention a bot not a user", color=self.colour)
          await ctx.send('you must mention a bot not a user :thumbsdown:')
          return
        else:
          embed=discord.Embed(description=f'{member.name} bot invite — **[here](https://discord.com/api/oauth2/authorize?client_id={member.id}&permissions=8&scope=bot)**', color=self.colour)
          #embed.set_thumbnail(url=f"{member.avatar_url}")
          #embed.set_footer(text=f"Resqusted By: {ctx.author} | Bot inv")
          await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(Util(bot))