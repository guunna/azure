import discord
import json
import pymongo
from discord.ext import commands
from colorama import Fore, Style

mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")

def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292
def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class addrole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Role" + Fore.RESET)

    @commands.guild_only()
    @commands.group()
    @commands.has_permissions(manage_roles=True)
    async def role(self, ctx):
        if ctx.invoked_subcommand is None:
            em = discord.Embed(title="Command: role", description="add/remove a role from a member", color=self.colour, timestamp=ctx.message.created_at)
            em.add_field(name="Sub Comamnds", value="```,role add <member> <role>\n,role create <role name>\n,role remove <member> <role>\n,role delete <role>\n,role all <role>\n,role rename <role> <name>```", inline=False)
            em.add_field(name="Aliases", value="N/A")
            em.add_field(name="Permissions", value="Manage Roles")
            em.add_field(name="Arguments", value="Subcommand, Member, Role")
            em.add_field(name="Command Usage", value="```Syntax: ,role [subcommand] [member] [role]\nExample: ,role add @forge @god```", inline=False)
            em.set_author(name="azure help", icon_url=f"{ctx.author.avatar_url}")
            em.set_footer(text="Command Module: Role")
            await ctx.send(embed=em)
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def add(self, ctx, member: discord.Member=None, role: discord.Role=None):
        if role.position >= ctx.guild.me.top_role.position:
            embedidk= discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: my role is under {role.mention}.",color=discord.Colour.from_rgb(255,172,28))
            await ctx.send(embed=embedidk)
            return
        elif role.position > ctx.author.top_role.position:
            embedlol = discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: {role.mention} is above you", color=discord.Colour.from_rgb(255,172,28))
            await ctx.send(embed=embedlol)
            return
        elif role == ctx.author.top_role.position:
              embedbored1 = discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: {role.mention} is same as you", color=discord.Colour.from_rgb(255,172,28))
              await ctx.send(embed=embedbored1)
              return
        else:
            await member.add_roles(role, reason=f"role added: {ctx.author}") 
            embed2 = discord.Embed(description=f"<:add:909968797111291905> {ctx.author.mention}: Added {role.mention} to {member.mention}", color=discord.Colour.from_rgb(0, 150, 255))
            await ctx.send(embed=embed2) 
            return
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def remove(self, ctx, member: discord.Member=None, role: discord.Role=None):
        if role.position >= ctx.guild.me.top_role.position:
            embedidk= discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: my role is under {role.mention}.",color=discord.Colour.from_rgb(255,172,28))
            await ctx.send(embed=embedidk)
            return
        elif role.position > ctx.author.top_role.position:
            embedlol = discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: {role.mention} is above you", color=discord.Colour.from_rgb(255,172,28))
            await ctx.send(embed=embedlol)
            return
        elif role == ctx.author.top_role.position:
              embedbored1 = discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: {role.mention} is same as you", color=discord.Colour.from_rgb(255,172,28))
              await ctx.send(embed=embedbored1)
              return
        else:
            await member.remove_roles(role, reason=f"role removed: {ctx.author}") 
            #embed2 = discord.Embed(description=f"<:remove:909969015227691059> {ctx.author.mention}: Removed {role.mention} from {member.mention}", color=discord.Colour.from_rgb(0, 150, 255))
            embed2 = discord.Embed(description=f"<:remove:909969015227691059> {ctx.author.mention}: Removed {role.mention} from {member.mention}", color=discord.Colour.from_rgb(0, 150, 255))
            await ctx.send(embed=embed2)
            return
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def create(self, ctx,*, name):
        guild = ctx.guild
        await guild.create_role(name=name)
        await ctx.send(f'creeated a role named **{name}** :thumbsup:')#static
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def delete(self, ctx, role:discord.Role=None):
        guild = ctx.guild
        await guild.delete_role(role=role)
        await ctx.send(f'deleted role **{role}** :thumbsup:')
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def rename(self, ctx, role: discord.Role=None, name=None):
        role = ctx.guild.get_role(role)
        await role.edit(name=f"{name}")
        await ctx.send(f"changed **{role}'s** name to **{name}**")
    
    @role.command()
    @commands.has_permissions(manage_roles=True)
    async def all(self, ctx, *, role: discord.Role=None):
        num = 0
        failed = 0
        for user in list(ctx.guild.members):
            try:
                await user.add_roles(role)
                num += 1
            except Exception:
                failed += 1
        await ctx.send(embed=discord.Embed(description=f"<:approve:906649360396353567> added **{role.name}** to **{num}** members didnt add to **{failed}**",color=self.good))

def setup(bot):
    bot.add_cog(addrole(bot))
    print('Config Cog Is Ready!')