import discord
from discord.ext import commands
import datetime
import os
import requests
import math
import asyncio
import pymongo
import asyncio
import time
import colorama 
from colorama import Fore, Style

def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

class Unban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
        print(f"{Fore.CYAN}[Status] Cog Loaded: Unban" + Fore.RESET)
    
    @commands.command(
        name='getserver',
        description='Dev Only | Gets info on the server',
        usage='getserver <guild_id>',
        aliases=["getguild", "gs"]
    )
    @commands.is_owner()
    async def getserver(self, ctx, id: int):
        output = ''
        guild = self.bot.get_guild(id)
        channel = guild.text_channels[0]
        i = await channel.create_invite(unique=True)
        if not guild:
            return await ctx.send("i was never in that guild :thumbsdown:")
        au1 = guild.name
        au2 = str(guild.id)
        au3 = str(len(guild.members))
        au4 = str(guild.owner)
        output += f'id: `{guild.id}`\nmembers: **{len(guild.members)}**\nstatus: `PAID`\ninvite: **[here]({i})**\n\n**owner**\n{guild.owner} `({guild.owner.id})`'
        embed = discord.Embed(
            colour=self.colour,
            title=f'{guild.name} — server info',
            description=output
        )
        embed.set_thumbnail(url=ctx.guild.icon_url)
        await ctx.send(embed=embed)
    
    @commands.command(
        name='guilds',
        description='Owner Only | List the servers that the bot is in',
        usage='servers',
        aliases=["serverlist", "gl"]
    )
    #@blacklist_check()    
    @commands.is_owner()
    async def guilds(self, ctx, page: int = 1):
     output = ''
     guilds = self.bot.guilds
     pages = math.ceil(len(guilds)/15)
     if 1 <= page <= pages:
            counter = 1+(page-1)*15
            for guild in guilds[(page-1)*15:page*15]:
                gn = guild.name
                gi = str(guild.id)
                gm = str(len(guild.members))
                go = str(guild.owner)
                output += f'<:right:904917173548494900> `{gn}` **|** `{gi}` **|** `{gm}` **|** `{go}`\n'
                counter += 1
            embed = discord.Embed(
                colour=self.colour,
                description=output,
                title=f'{len(self.bot.guilds)} Guilds!',
                timestamp=ctx.message.created_at
            )
            embed.set_footer(
                text=f'Page {page} of {pages}'
            )
            msg = await ctx.send(
                embed=embed
            )
            await msg.add_reaction("<:left:904917144645546004>")
            await msg.add_reaction("<:right:904917173548494900>")
            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["<:arrowright:897514894386139136>", "<:left:904917144645546004>"]
            while True:
              try:
                reaction, user = await self.bot.wait_for("reaction_add", timeout=60, check=check)
                if str(reaction.emoji) == "<:left:904917144645546004>":
                  page -= 1
                elif str(reaction.emoji) == "<:right:904917173548494900>":
                  page += 1
              except asyncio.TimeoutError:
                await msg.remove_reaction(reaction, ctx.author)
                await msg.remove_reaction(reaction, ctx.author)
                await msg.remove_reaction(reaction, self.bot.user)
                await msg.remove_reaction(reaction, self.bot.user)
    
    @commands.command(
      name="unbanall",
      description="Anti Feature | Removes all bans in the current server.",
      usage="unbanall",
      aliases=["massunban", "purgebans", "clearbans", "cb"]
    )
    @commands.has_permissions(ban_members=True)
    async def unbanall(self, ctx):
        if not ctx.message.guild:
            return
        else:          
            tic = time.perf_counter()
            banlist = await ctx.guild.bans()
            members = [str(f'`{users.user}` **|** `{users.user.id}`') for users in banlist]
            ping = float(f'0.{int(self.bot.latency * 1000)}') / 3
            est_time = round(len(members) * ping)
            txt = await ctx.send(embed=discord.Embed(description=f"<:wait:921812565418459156> unbanning members please wait..", color=self.colour))
            for users in banlist:
                try:
                    await ctx.guild.unban(user=users.user)
                except:
                    pass    
            toc = time.perf_counter()
            if len(members) == 0:
                await txt.edit(f'theres no banned users to unban :thumbsdown:')
                return

            per_page = 15 
            pages = math.ceil(len(members) / per_page)
            cur_page = 1
            chunk = members[:per_page]
            linebreak = "\n"
            
            em = discord.Embed(title=f"{len(members)} Users unbanned:", description=f"{linebreak.join(chunk)}", colour=self.colour)
            em.set_footer(text=f"Page {cur_page}/{pages}")            
            message = await ctx.send(f"Took `{round(toc - tic)}` second(s) to unban `{len(members)}` members", embed=em)
            reaction = await message.add_reaction("<:left:904917144645546004>")
            reaction = await message.add_reaction("<:right:904917173548494900>")
            user = ctx.author
            active = True

            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["<:right:904917173548494900>", "<:left:904917144645546004>"]

            while active:
                try:
                    reaction, user = await self.bot.wait_for("reaction_add", timeout=60, check=check)
                
                    if str(reaction.emoji) == "<:right:904917173548494900>" and cur_page != pages:
                        cur_page += 1
                        if cur_page != pages:
                            chunk = members[(cur_page-1)*per_page:cur_page*per_page]
                        else:
                            chunk = members[(cur_page-1)*per_page:]
                        e = discord.Embed(title=f"{len(members)} Users unbanned:", description=f"{linebreak.join(chunk)}", colour=self.color)
                        e.set_footer(text=f"Page {cur_page}/{pages}:")
                        await message.edit(embed=e)
                        await message.remove_reaction(reaction, user)
                    elif str(reaction.emoji) == "<:left:904917144645546004>" and cur_page > 1:
                        cur_page -= 1
                        chunk = members[(cur_page-1)*per_page:cur_page*per_page]
                        e = discord.Embed(title=f"{len(members)} Users unbanned:", description=f"{linebreak.join(chunk)}", colour=self.color)
                        e.set_footer(text=f"Page {cur_page}/{pages}:")
                        await message.edit(embed=e)
                        await message.remove_reaction(reaction, user)
                except asyncio.TimeoutError:
                    await message.remove_reaction(reaction, user)
                    await message.remove_reaction(reaction, self.bot.user)
                    await message.remove_reaction(reaction, user)
                    await message.remove_reaction(reaction, self.bot.user)
                    active = False

def setup(bot):
    bot.add_cog(Unban(bot))