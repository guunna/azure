import discord
import json
from discord.ext import commands
from colorama import Fore, Style
import pymongo
mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
blacklist = mongodb.get_database("discord").get_collection("blacklists")
def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

class autorole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
    
    @commands.guild_only()
    @commands.group(aliases=['ar'])
    @blacklist_check()
    @commands.has_permissions(manage_roles=True)
    async def autorole(self, ctx):
     if ctx.invoked_subcommand is None:
         em = discord.Embed(title="Comamnd: autorole", description="set server autorole", color=self.colour, timestamp=ctx.message.created_at)
         em.add_field(name="Sub Commands", value="```,autorole add```", inline=False)
         em.add_field(name="Aliases", value="ar")
         em.add_field(name="Permissions", value="Manage Role")
         em.add_field(name="Arguments", value="Subcommand, Role")
         em.add_field(name="Command Usage", value="```Syntax: ,autorole [subcommand] [role]\nExample: ,autorole add @members```", inline=False)
         em.set_author(name="azure help", icon_url=ctx.author.avatar_url)
         em.set_footer(text="Command Module: Autorole")
         await ctx.send(embed=em)
         print('autorole cmd used') 
	    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            with open("./data/autorole.json", "r") as f:
                roles = json.load(f)
            role = roles[str(member.guild.id)]

            joinrole = discord.utils.get(member.guild.roles, id=role)
            await member.add_roles(joinrole, atomic=True)
        except KeyError:
            pass
	     
    @autorole.command(aliases=['+'])  
    @blacklist_check()   
    @commands.has_permissions(manage_roles=True)
    async def add(self, ctx, role: discord.Role):
        with open("./data/autorole.json", "r") as f:
            roles = json.load(f)

        roles[str(ctx.guild.id)] = role.id

        with open("./data/autorole.json", "w") as f:
            json.dump(roles, f, indent=4)
        embed = discord.Embed(description=f"autorole set to {role.mention}",  color=discord.Colour.from_rgb(184, 153, 255))
        await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(autorole(bot))
    print(f"{Fore.CYAN}[Status] Cog Loaded: Autorole" + Fore.RESET)