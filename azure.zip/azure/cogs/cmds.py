import discord
import pymongo 
from pymongo import MongoClient, results
import colorama 
from colorama import Fore
from discord.ext import commands
import math

def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292


mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("guilds")
db2 = mongodb.get_database("discord").get_collection("protection")
blacklist = mongodb.get_database("discord").get_collection("blacklists")

def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

def is_server_owner(ctx):
    return ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292

def is_whitelisted(ctx):
    return ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["whitelisted"] or ctx.message.author.id == 717206196091617292


class cmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.colour = discord.Colour.from_rgb(105,145,157)
        self.good = discord.Colour.from_rgb(164, 235, 120)
        self.bad = discord.Colour.from_rgb(255, 100, 100)
    
    @commands.group(aliases=['an', 'antiwizz', 'aw'])
    @blacklist_check()
    async def antinuke(self, ctx):
        if ctx.invoked_subcommand is None:
            #embed = discord.Embed(description=f"antinuke is **DOWN** under developement")
            embed = discord.Embed(title=f"Command: antinuke", description=f"configurable anti nuke/wizz to limit bans, kicks, channel deletions, and role changes/updates with customizable limits", color=self.colour, timestamp=ctx.message.created_at)
            embed.add_field(name=f"Sub Commands", value=f"```,antinuke whitelist\n,antinuke unwhitelist\n,antinuke settings```", inline=False)
            embed.add_field(name="Aliases", value="an, antiwizz, aw")
            embed.add_field(name="Permissions", value="Guild Owner")
            embed.add_field(name="Arguments", value="Subcommand, Member")
            embed.add_field(name="Command Usage", value="```Syntax: ,antinuke [subcommand] <member>\nExample: ,antinuke whitelist @forge```", inline=False)
            embed.set_author(name="azure help", icon_url=ctx.author.avatar_url)
            embed.set_footer(text="Command Module: Antinuke")
            await ctx.send(embed=embed)
    
    @antinuke.command(aliases=['wl', 'ignore'])
    @blacklist_check()
    async def whitelist(self, ctx, member:discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292:
            db.update_one({ "guild_id": ctx.guild.id }, { "$push": { "whitelisted": member.id}})
            embed = discord.Embed(title='', color=self.good, description=f'<:approve:906649360396353567> {ctx.author.mention}: **{member}** is now whitelisted')
            #embed.set_thumbnail(url='https://cdn.discordapp.com/icons/795579014122438688/e2cb59f60423ffd8f561f40827400fe3.webp?size=1024')
            await ctx.send(embed=embed)

    @antinuke.command(aliases=['uwl', 'untrust'])
    @blacklist_check()
    async def unwhitelist(self, ctx, member: discord.Member=None):
        if ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292:
                db.update_one({ "guild_id": ctx.guild.id }, { "$pull": { "whitelisted": member.id }})
                embed = discord.Embed(title='', color=self.good, description=f'<:approve:906649360396353567> {ctx.author.mention}: **{member}** is now unwhitelisted')
            #embed.set_thumbnail(url='https://cdn.discordapp.com/icons/795579014122438688/e2cb59f60423ffd8f561f40827400fe3.webp?size=1024')
                await ctx.send(embed=embed)
    
    @antinuke.command(aliases=['wld', 'trusted'])
    @blacklist_check()#{ctx.bot.get_user(i)}
    @commands.check(is_server_owner)
    async def settings(self, ctx):
        data = db.find_one({ "guild_id": ctx.guild.id })['whitelisted']
        embed = discord.Embed(title=f"Whitelist for {ctx.guild.name}", description="\n", color=self.colour)
        embed.set_footer(text="all of a user's roles will be removed when a limit is hit")
        for i in data:
          if ctx.bot.get_user(i) != None:
            if ctx.bot.get_user(i) == ctx.guild.owner:
              embed.description += f"<:owner:911470000630558731> **|** <@{i}> / `{i}`\n"
            if ctx.bot.get_user(i) != ctx.guild.owner:
              if ctx.bot.get_user(i).bot:
                embed.description += f"<:bot:909978089658925167> **|** <@{i}> / `{i}`\n"
              else:
                embed.description += f"<:members:911444526818787418> **|** <@{i}> / `{i}`\n"
        await ctx.send(embed=embed)
    @antinuke.command()
    async def wenis(self, ctx, page: int = 1):
      output = ''
      data = db.find_one({ "guild_id": ctx.guild.id })['whitelisted']
      pages = math.ceil(data.count()/10)
      if 1 <= page <= pages:
            counter = 1+(page-1)*10
            for member in data[(page-1)*10:page*10]:
              output += f'`{counter}` **{member}** / `{member.id}`\n'
              counter += 1
              embed = discord.Embed(title="Whitelisted", description=output, color=self.colour)
              embed.set_footer(text=f'Page {page}/{pages}')
              await ctx.send(embed=embed)
    





def setup(bot):
    bot.add_cog(cmds(bot))
    print(f"{Fore.CYAN}[Status] Cog Loaded: Cmds" + Fore.RESET)