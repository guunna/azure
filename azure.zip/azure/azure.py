﻿import os
import datetime
import discord
from asyncio import sleep
import re
import asyncio
import pymongo
import aiohttp
import math
import datetime
import io
import base64
import time
import random
from bs4 import BeautifulSoup as bs4
import requests
import colorama
from colorama import Fore
import json
from textwrap import indent
from discord.ext import commands
import sys
import sqlite3
from discord_components import DiscordComponents, Button, Select, SelectOption, ButtonStyle


def restart_bot(): 
  os.execv(sys.executable, ['python'] + sys.argv)
#cluster = mongodb("mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority")
#mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
mongodb = pymongo.MongoClient('mongodb+srv://autmn:lol@cluster0.kz2d8.mongodb.net/discord?retryWrites=true&w=majority')
db = mongodb.get_database("discord").get_collection("guilds")
db2 = mongodb.get_database("discord").get_collection("protection")
blacklist = mongodb.get_database("discord").get_collection("blacklists")
whitelistedservers = mongodb.get_database("discord").get_collection("whitelisted servers")


def blacklist_check():
    def predicate(ctx):
        author_id = ctx.author.id
        if blacklist.find_one({'user_id': author_id}):
            return False
        return True
    return commands.check(predicate)

def is_server_owner(ctx):
    return ctx.message.author.id == ctx.guild.owner.id or ctx.message.author.id == 717206196091617292

os.environ['JISHAKU_NO_UNDERSCORE'] = 'True'
os.environ['JISHAKU_RETAIN'] = 'True'

def is_owner(ctx):
    return ctx.message.author.id == 717206196091617292

def is_whitelisted(ctx):
    return ctx.message.author.id in db.find_one({ "guild_id": ctx.guild.id })["whitelisted"] or ctx.message.author.id == 717206196091617292


def get_prefix(bot, message):
    with open("prefixes.json", "r") as f:
        prefixes = json.load(f)
    return prefixes.get(str(message.guild.id), ",")



#intents=discord.Intents.all()
#intents.members = True
bot = commands.AutoShardedBot(
    command_prefix=get_prefix,
    help_command=None,
    intents=discord.Intents.all(),
    allowed_mentions=discord.AllowedMentions(everyone=False, roles=True, users=True),
    help_attrs=dict(hidden=False),
    heartbeat_timeout=200.0,
    case_insensitive=True,
    owner_ids={717206196091617292},
)

color = discord.Colour.from_rgb(105,145,157)
good = discord.Colour.from_rgb(164, 235, 120)
bad = discord.Colour.from_rgb(255, 100, 100)
red = discord.Colour.from_rgb(255, 0, 0)
#color = discord.Colour.from_rgb(184, 153, 255)
bot.load_extension('jishaku')
print(f"{Fore.CYAN}[Status] Loading Cogs..." + Fore.RESET)

client = bot 
for filename in os.listdir('./cogs'):
    if filename.endswith('.py') and not filename.startswith('_'):
        client.load_extension(f'cogs.{filename[:-3]}')      
@bot.event 
async def on_ready():
    DiscordComponents(bot)
    print(f'ready')

authorises = [717206196091617292]

def check_if_can_auth(ctx):
    if ctx.author.id in authorises:
        return ctx.author.id in authorises

@client.event
async def on_raw_reaction_add(payload):

    if payload.member.bot:
        pass

    else:
        with open('reactrole.json') as react_file:
            data = json.load(react_file)
            for x in data:
                if x['emoji'] == payload.emoji.name:
                    role = discord.utils.get(client.get_guild(
                        payload.guild_id).roles, id=x['role_id'])

                    await payload.member.add_roles(role)


@client.event
async def on_raw_reaction_remove(payload):

    with open('reactrole.json') as react_file:
        data = json.load(react_file)
        for x in data:
            if x['emoji'] == payload.emoji.name:
                role = discord.utils.get(client.get_guild(
                    payload.guild_id).roles, id=x['role_id'])

                
                await client.get_guild(payload.guild_id).get_member(payload.user_id).remove_roles(role)

@client.group(invoke_without_command=True, aliases=['rr'])
@commands.has_permissions(administrator=True, manage_roles=True)
async def reactrole(ctx):
    e = discord.Embed(title="Command: reactrole", description=f"sets servers reaction role", color=color, timestamp=ctx.message.created_at)
    e.add_field(name="Sub Commands", value=f"```,reactrole add```", inline=False)
    e.add_field(name="Aliases", value="rr")
    e.add_field(name="Permissons", value="Admin, Manage Role")
    e.add_field(name="Arguments", value="Subcommand, Emoji, Role, Message")
    e.add_field(name="Command Usage", value="```Syntax: ,reactrole [subcommand] [emoji] [role] [message]\nExample: ,reactrole add :lol: @members verify here```", inline=False)
    e.set_author(name="azure help", icon_url=ctx.author.avatar_url)
    e.set_footer(text="Command Module: Reaction Role")
    await ctx.send(embed=e)

@reactrole.command()
async def add(ctx, emoji, role: discord.Role, *, message):

    emb = discord.Embed(description=message, color=color)
    msg = await ctx.channel.send(embed=emb)
    await msg.add_reaction(emoji)

    with open('reactrole.json') as json_file:
        data = json.load(json_file)

        new_react_role = {'role_name': role.name, 
        'role_id': role.id,
        'emoji': emoji,
        'message_id': msg.id}

        data.append(new_react_role)

    with open('reactrole.json', 'w') as f:
        json.dump(data, f, indent=4)


@client.group(invoke_without_command=True, aliases=['guild'])
@commands.check(check_if_can_auth)
async def server(ctx):
    e = discord.Embed(title="Command: server", description=f"allows/unallow {bot.user.name} to join servers", color=color, timestamp=ctx.message.created_at)
    e.add_field(name="Sub Commands", value=f"```,server allow\n,server deny\n,server transfer```", inline=False)
    e.add_field(name="Aliases", value="guild")
    e.add_field(name="Permissons", value="Bot Owner")
    e.add_field(name="Arguments", value="Subcommand, Guild ID")
    e.add_field(name="Command Usage", value="```Syntax: ,server [subcommand] [guild ID]\nExample: ,server allow 923290554018717747```", inline=False)
    e.set_author(name="azure help", icon_url=ctx.author.avatar_url)
    e.set_footer(text=f"Command Module: Server Auth")
    await ctx.send(embed=e)

@server.command(aliases=['xfer'])
@commands.check(check_if_can_auth)
async def transfer(ctx, serverid: int, serverid2: int, member: discord.Member=None):
    if member == None:
        whitelistedservers.delete_one({"_id": serverid})
        await bot.get_guild(int(serverid)).leave()
        whitelistedservers.insert_one({"_id": serverid2})
        await ctx.send(f'transferred guild **{serverid}** :thumbsup:\n— to: **{serverid2}**')
    else:
        whitelistedservers.delete_one({"_id": serverid})
        whitelistedservers.insert_one({"_id": serverid2})
        await ctx.send(f'transferred guild **{serverid}** :thumbsup:\n— to: **{serverid2}**')
        await member.send('thanks for buying azure !!\n— **forge#1337**')

@server.command(aliases=['wl'])
@commands.check(check_if_can_auth)
async def allow(ctx, serverid: int, member: discord.Member=None):
    if member == None:
        whitelistedservers.insert_one({"_id": serverid})
        await ctx.send(f'whitelisted guild **{serverid}** :thumbsup:')
    else:
        whitelistedservers.insert_one({"_id": serverid})
        await member.send(f'thanks for buying azure !!\n\n— **forge#1337**')
        await ctx.send(f'whitelisted guild **{serverid}** :thumbsup:\n— sent dm to **{member}**')

@bot.command(aliases=['r', 'res'])
async def restart(ctx):
    if ctx.author.id == 717206196091617292:
      #await ctx.send(embed=discord.Embed(description=f"<a:loading:906654410413846548> {ctx.author.mention}: **Restarting {bot.user.name}**, please wait", color=color))
      await ctx.send(f'restarting **azure** :thumbsup:')
      os.system('cls')
      await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing,name=f"Restarting..."))
      restart_bot()
    else:
      return

@server.command(aliases=['uwl'])
@commands.check(check_if_can_auth)
async def deny(ctx, serverid: int):
    if whitelistedservers.find_one({"_id": serverid}):
        whitelistedservers.delete_one({"_id": serverid})

        await ctx.send(f'**{serverid}** has been unwhitelisted :thumbsup:')
        await bot.get_guild(int(serverid)).leave()
    else:
        await ctx.send(f'**{serverid}** was never whitelisted :thumbsdown:')

@bot.event
async def on_connect():
            await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing,name=f"discord.gg/matching"))
            print(f"{Fore.GREEN}[{Fore.RESET}LOADED{Fore.GREEN}]{Fore.GREEN}[{Fore.RESET}SUCCESS{Fore.GREEN}] Azure")
   
upsince = datetime.datetime.now()

start_time = datetime.datetime.utcnow()


class aries:


    def newserver(owner_id, server_id):
        db.insert_one({
            "whitelisted": [owner_id, 717206196091617292, 919286458181898300],
            "punishment": "ban",
            "log": None,
            "guild_id": server_id
        })
        db2.insert_one({
          "guild_id": server_id,
          "role": 'Enabled',
          "channel": 'Enabled',
          "channel_del": 'Enabled',
          "role_del": 'Enabled',
          "ban": 'Enabled',
          "kick": 'Enabled',
          "bot": 'Enabled',
          "role_update": 'Enabled',
          "webhook_creation": 'Enabled',
        })

@bot.command()
async def rules(ctx):
    em = discord.Embed(title="rules", description="- no illegal shit\n- dont harass people\n- no malicious content/links\n- no gore/disgusting shit- no spamming\n\n- follow discord policies\n— https://discord.com/terms\n— https://discord.com/guidelines", color=color)
    em.set_thumbnail(url="https://cdn.discordapp.com/attachments/909152029908271174/914926100273037382/unknown.png")
    em.set_footer(text="azure on top ..")
    await ctx.send(embed=em)

@bot.command(aliases=["prefix"])
@blacklist_check()
@commands.has_permissions(administrator=True)
@commands.cooldown(1, 8, commands.BucketType.channel)
async def setprefix(ctx, prefix):
    with open("prefixes.json", "r") as f:
        prefixes = json.load(f)
    prefixes[str(ctx.guild.id)] = prefix
    with open("prefixes.json", "w") as f:
        json.dump(prefixes, f, indent=4)
        await ctx.send(f'my prefix has been changed to `{prefix}`.')

@client.command()
@blacklist_check()
@commands.has_permissions(manage_channels=True)
@commands.cooldown(1,5, commands.BucketType.user)
async def nuke(ctx):
    channel_id = ctx.channel.id
    channel = client.get_channel(channel_id)
    new_channel = await ctx.guild.create_text_channel(name=channel.name, topic=channel.topic, overwrites=channel.overwrites, nsfw=channel.nsfw, category=channel.category, slowmode_delay=channel.slowmode_delay, position=channel.position)
    await channel.delete()
    embed = discord.Embed(color=color, title=f"Nuked {channel}", timestamp=ctx.message.created_at)
    embed.set_image(url="https://media.discordapp.net/attachments/804799518217994335/804809066257055794/image0.gif")
    await new_channel.send(f"the channel has been nuked 💥")

@bot.event
async def on_command_error(ctx, error):
  if isinstance(error, commands.MissingPermissions):
      await ctx.send(embed=discord.Embed(description=f'<:warn:902841734529183775> {ctx.author.mention}: You\'re **missing** the permission: `{"".join(error.missing_perms)}`',color=discord.Colour.from_rgb(255,172,28)))
   #await ctx.send(embed=discord.Embed(description=f'<:warn:902841734529183775> {ctx.author.mention}: Youre **missing** the permission: `{"".join(error.missing_perms)}`',color=discord.Colour.from_rgb(255,172,28)))
  if isinstance(error, commands.MemberNotFound):
      await ctx.send(embed=discord.Embed(description=f'<:warn:902841734529183775> {ctx.author.mention}: I was unable to find that **member** or the **ID** is invalid',color=discord.Colour.from_rgb(255,172,28)))
      #await ctx.send("i couldn't find any members with that name")
  if isinstance(error, commands.UserNotFound):
      await ctx.send(embed=discord.Embed(description=f'<:warn:902841734529183775> {ctx.author.mention}: I was unable to find that **user** or the **ID** is invalid',color=discord.Colour.from_rgb(255,172,28)))
      #await ctx.send(embed=discord.Embed(description=f"<:warn:902841734529183775> {ctx.author.mention}: **Unknown User**, i cannot find that user.",color=discord.Colour.from_rgb(255,172,28)))
    #await ctx.send("i couldn't find any users with that name")

@bot.event
@blacklist_check()
async def on_message(message):
    botID = 919286458181898300
    if message.content == f'<@!{botID}>':
        await message.channel.send(f'prefix: `{str(get_prefix(bot, message))}`')

    await bot.process_commands(message)

@bot.event
async def enabled_guild_remove(guild):
    with open("prefixes.json", "r") as f:
        prefixes = json.load(f)

    prefixes.pop[str(guild.id)]
    with open("prefixes.json", "w") as f:
        json.dump(prefixes, f, indent=4)

@bot.command()
@blacklist_check()
async def uptime(ctx):
    now = datetime.datetime.utcnow(
    )  # Timestamp of when uptime function is run
    delta = now - start_time
    hours, remainder = divmod(int(delta.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    days, hours = divmod(hours, 24)
    if days:
        time_format = "**{d}d {h}h {m}m and {s}s**"
    else:
        time_format = "**{h}h {m}m and {s}s**"
    uptime_stamp = time_format.format(d=days, h=hours, m=minutes, s=seconds)
    em = discord.Embed(description=f"{bot.user.name} has been running for: {uptime_stamp}", color=color)
    await ctx.send(embed=em)

@bot.command()
@blacklist_check()
async def version(ctx):
    await ctx.send(embed=discord.Embed(description=f"{bot.user.name} — **v0.6.2**", color=color))
#await ctx.sned(embed=embed(description

@bot.command(aliases=['base64', 'bs4'])
@blacklist_check()
async def b64(ctx, task=None, *, string=None):
    if ctx.author.nick == None:
        username = ctx.author.name
    else:
        username = ctx.author.nick

    if task == 'encode':
        stringBytes = string.encode("ascii")

        b64Bytes = base64.b64encode(stringBytes)
        b64String = b64Bytes.decode("ascii")

        await ctx.send(f"```{b64String}```")

    if task == 'decode':
        b64Bytes = string.encode("ascii")

        stringBytes = base64.b64decode(b64Bytes)
        decodedString = stringBytes.decode("ascii")
        await ctx.send(f"```{decodedString}```")

    if task == None:
        e = discord.Embed(title="Command: ,base64", description="encode or decode a base64 string", color=color, timestamp=ctx.message.created_at)
        e.add_field(name="Sub Commands", value="```,base64 encode\n,base64 decode```", inline=False)
        e.add_field(name="Aliases", value="b64")
        e.add_field(name="Permissions", value="N/A")
        e.add_field(name="Arguments", value="Subcommand, String")
        e.add_field(name="Command Usage", value="```Syntax: ,base64 [subcommand] [string]\nExample: ,base64 encode i love forge```", inline=False)
        e.set_footer(text="Command Module: Base64")
        e.set_author(name="azure help", icon_url=ctx.author.avatar_url)
        await ctx.send(embed=e)
        #await ctx.send(embed=discord.Embed(title=f"base64", description=f"encode or decode a base64 string \n\n**usage**\nbase64 decode [string]\nbase64 encode [string]\n\n**aliases**\nb64, base64", color = color))



@bot.command(aliases=['b', 'deport', 'yeet'])
@blacklist_check()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member = None, *, reason=None):
  if member == None:
      e = discord.Embed(title="Command: ban", description=f"Bans the mentioned user from the guild\n```Syntax: ,ban (user) <reason>\nExample: ,ban forge#1337 dont like u```", color=color)
      #e.add_field(name="Aliases", value="deport, yeet")
      #e.add_field(name="Module", value="Moderation")
      #e.add_field(name="Cooldown", value="N/A")
      #e.add_field(name="Usage", value="```,ban [member] [reason]```")
      e.set_author(name="azure help", icon_url=ctx.author.avatar_url)
      await ctx.send(embed=e)
  elif member.top_role >= ctx.author.top_role:
      await ctx.send(f'i cannot **ban** someone whos **higher** then me :thumbsdown:')
        #await ctx.send(embed=discord.Embed(description=f"<:deny:903751730880213062> {ctx.author.mention}: I can't **ban** someone who is **higher** than me.", color=discord.Colour.from_rgb(255,100,101)))
  elif ctx.author == member:
      await ctx.send(':thumbsdown: - this member is above you.')
  elif ctx.guild.owner == member:
      await ctx.send(f'you **cannot** ban the **guild owner** :thumbsdown:')
      #await ctx.send(embed=discord.Embed(description=f"<:deny:903751730880213062> {ctx.author.mention}: you **cannot** ban **guild owner**", color=discord.Colour.from_rgb(255,100,101)))
  elif ctx.author.top_role < member.top_role:
      await ctx.send(f':thumbsdown: - unable to ban **{member}**')   
  elif reason == None:
     reason = "N/A" 
     #em = discord.Embed(title="banned", description=f"Moderator: `{ctx.author}`\nReason: `{reason}`", color=color)
     #em.set_thumbnail(url=f"{ctx.guild.icon_url}")
     #em.set_footer(text=f"{ctx.guild.name}")
     #await member.send(embed=em)
     await member.ban(reason=reason)
     await ctx.send(f':thumbsup:')
  else:
     #em = discord.Embed(title="banned", description=f"Moderator: `{ctx.author}`\nReason: `{reason}`", color=color)
     #em.set_thumbnail(url=f"{ctx.guild.icon_url}")
     #em.set_footer(text=f"{ctx.guild.name}")
     #await member.send(embed=em)
     await member.ban(reason=reason)
     await ctx.send(f':thumbsup:')

    #await member.ban(reason=reason)
    #await ctx.send(embed=discord.Embed(description=f"<:successful:875765462607228978> **succesfully banned** `{member.name}` **|** `{reason}`", color=color))

@bot.command(aliases=['boot', 'pm'])
@blacklist_check()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member = None, *, reason=None):
  if member == None:
      e = discord.Embed(title="Command: kick", description=f"Kicks the mentioned user from the guild\n```Syntax: ,kick (user) <reason>\nExample: ,kick forge#1337 dont like u```", color=color)
      #e.add_field(name="Aliases", value="deport, yeet")
      #e.add_field(name="Module", value="Moderation")
      #e.add_field(name="Cooldown", value="N/A")
      #e.add_field(name="Usage", value="```,ban [member] [reason]```")
      e.set_author(name="azure help", icon_url=ctx.author.avatar_url)
      await ctx.send(embed=e)
  elif member.top_role >= ctx.author.top_role:
      await ctx.send(f'i cannot **ban** someone whos **higher** then me :thumbsdown:')
        #await ctx.send(embed=discord.Embed(description=f"<:deny:903751730880213062> {ctx.author.mention}: I can't **kick** someone who is **higher** than me.", color=discord.Colour.from_rgb(255,100,101)))
  elif ctx.author == member:
      await ctx.send(':thumbsdown: - you cannot kick yourself')
  elif ctx.guild.owner == member:
      await ctx.send(f'you **cannot** ban the **guild owner** :thumbsdown:')
      #await ctx.send(embed=discord.Embed(description=f"<:deny:903751730880213062> {ctx.author.mention}: you **cannot** kick **guild owner*", color=discord.Colour.from_rgb(255,100,101)))   
  elif ctx.author.top_role < member.top_role:
      await ctx.send(f':thumbsdown: - unable to pm **{member}**')   
  elif reason == None:
     reason = "N/A"
     await member.kick(reason=reason)
     #await member.send(em=discord.Embed(title="ban", description=f"**reason**: {reason}\n**moderator**: {ctx.author}", ))
     await ctx.send(f':thumbsup:')
  else:
      await member.kick()
      await ctx.send(f':thumbsup:')

@bot.command(aliases=['i', 'inv'])
@blacklist_check()
async def invite(ctx):
    em = discord.Embed(description=f"contact forge#1337 to purchase {bot.user.name} for your server, or join the [support server](https://discord.gg/2ZSh7G2KrX) for more info.\n> if {bot.user.name} was accidentally removed, invite it [here](https://discord.com/api/oauth2/authorize?client_id=919286458181898300&permissions=8&scope=bot%20applications.commands)", color=color)
    em.set_author(name=f"{bot.user.name} costs a one-time $3/server.", icon_url=f"{bot.user.avatar_url}")
    await ctx.send(embed=em)



@commands.has_permissions(manage_messages=True)
@bot.command()
@blacklist_check()
async def purge(ctx, amount=0):
      await ctx.channel.purge(limit=amount)
      await ctx.send(f":thumbsup: - purged **{amount}** messages", delete_after=3)

@bot.command()
#@blacklist_check()
async def leave(ctx, *, guildid: discord.Guild):
  if ctx.author.id == 717206196091617292: 
    await ctx.send(embed=discord.Embed(description=f"<:approve:906649360396353567> left guild: **{guildid.name}**", color=good))
    await guildid.leave()
    return

@bot.command(aliases=['rinv'])
@blacklist_check()
@commands.has_permissions(manage_messages=True)
async def reinvite(ctx, user: discord.User=None):
    guild = ctx.guild
    channel = guild.text_channels[0]
    inv = await channel.create_invite(unique=True)
    await ctx.send(f"**{user}** has been dm\\'d an invite ({inv.code}) :thumbsup:")
    await user.send(f'you have been reinvited to {inv}')
#717206196091617292
@bot.command(aliases=['sinv'])
async def serverinvite(ctx, *, guildid: discord.Guild):
 if ctx.author.id == 717206196091617292: 
    channel = guildid.text_channels[0]
    rope = await channel.create_invite(unique=True)
          #embed=discord.Embed(description=f'{member.name} bot invite —# **[here](https://discord.com/api/oauth2/authorize?client_id={member.id}&permissions=8&scope=bot)**', color=self.colour)
          #embed=discord.Embed(description=f'{member.name} bot invite — **[here](https://discord.com/api/oauth2/authorize?client_id={member.id}&permissions=8&scope=bot)**', color=self.colour)
    await ctx.send(embed=discord.Embed(description=f"{guildid.name} server invite — **[here]({rope})**", color=color))
 else:
     await ctx.send('BRUH ion got invite perms ')

@bot.command()
async def donate(ctx):
    embed=discord.Embed(description="**cashapp**: $zovyi\n**btc**:", color=color)
    embed.set_author(name=f"want to keep {bot.user.name} running?", icon_url="https://media.discordapp.net/attachments/915397698453131314/917806629611786290/777784280666865665.gif")
    await ctx.send(embed=embed)

@bot.command()
async def bugreport(ctx, *, bug):
    k = bot.get_channel(923353395820126258)
    e = discord.Embed(title="New Bug", description=f"**User**: `{ctx.author}` | `{ctx.author.id}`\n**Server**: `{ctx.guild.name}` | `{ctx.guild.id}`\n**Bug**: {bug}", color=color)
    await k.send(embed=e)
    await ctx.send('you bug as been reported :thumbsup:')

@bot.command()
async def feedback(ctx, *, feedback):
    f = bot.get_channel(923353385674104853)
    e = discord.Embed(title="FeedBack", description=f"**User**: `{ctx.author}` | `{ctx.author.id}`\n**Server**: `{ctx.guild.name}` | `{ctx.guild.id}`\n**FeedBack**: {feedback}", color=color)
    await f.send(embed=e)
    await ctx.send('thanks for your feedback has been sent to developers :thumbsup:')


    #await me.send(rope)
@bot.event
async def on_guild_join(guild):
    serverid = guild.id

    if whitelistedservers.find_one({"_id": serverid}):
        server = client.get_guild(guild.id)
        aries.newserver(server.owner.id, server.id)
        channel = guild.text_channels[0]
        inv = await channel.create_invite(unique=True)
        lol = await bot.fetch_user(717206196091617292)
        me = bot.get_channel(923352810232352798)
        e = discord.Embed(title="join logs", description=f"joined server **{guild.name}** with **{len(guild.members)}** members | guild id: **{guild.id}**", color=color)
        cock = discord.Embed(title=f"{guild.name} — joined server", description=f"id: `{guild.id}`\nmembers: **{len(guild.members)}**\nstatus: `PAID`\ninvite: **[here]({inv})**\n\n**owner**\n{guild.owner} `({guild.owner.id})`", color=discord.Colour.from_rgb(105,145,157))
        cock.set_thumbnail(url=guild.icon_url)
        await lol.send(embed=cock)
        await me.send(embed=e)
        #await me.send(f'i joined {guild} | {guild.id}')
 
    else:
        await bot.get_guild(int(serverid)).leave()

@bot.event
async def on_guild_remove(guild):
    me = bot.get_channel(923352810232352798)
    e = discord.Embed(title="leave logs", description=f"left server **{guild.name}** with **{len(guild.members)}** members | guild id: **{guild.id}**", color=color)
    await me.send(embed=e)

@bot.command(aliases=['bi', 'azure'])
@blacklist_check()
async def botinfo(ctx):
    #import psutil
   # mem = round(psutil.virtual_memory().percent,1)
    humans = len(list(filter(lambda m: not m.bot, bot.get_all_members())))
    now = datetime.datetime.utcnow(
    )
    delta = now - start_time
    hours, remainder = divmod(int(delta.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    days, hours = divmod(hours, 24)
    if days:
        time_format = "{d}d {h}h {m}m and {s}s"
    else:
        time_format = "{h}h {m}m and {s}s"
    uptime = time_format.format(d=days, h=hours, m=minutes, s=seconds)
    em = discord.Embed(description=f'Developer: **forge#1337**\nCommands: **{len(set(bot.walk_commands()))}**, Process Memory: **67.9MB**', color=color)
    em.add_field(name="Members", value=f"Total: {len(set(bot.get_all_members()))}\nUnique: {humans}")
    em.add_field(name="Channels", value="78003 Total\n3423 Text\n24525 Voice")
    em.add_field(name="Guilds", value=f"{len(bot.guilds)} (private)")
    em.set_author(name=f"{bot.user.name}", icon_url=bot.user.avatar_url)
    em.set_footer(text=f"{uptime}")
    await ctx.send(embed=em)

@bot.command(aliases=['av'])
@blacklist_check()
async def avatar(ctx, user: discord.User = None):
      user = ctx.author if not user else user
      embed = discord.Embed(title=f"{user.name}'s avatar",url=f"{user.avatar_url}", color=color)#discord.Colour.from_rgb(3, 2, 1)
      embed.set_image(url=user.avatar_url)
      embed.set_author(name=f"{ctx.author.name}", icon_url=ctx.author.avatar_url)
      await ctx.send(embed=embed, components=[
                Button(
                    style=ButtonStyle.URL,
                    label="Avatar",
                    url=
                    f"{user.avatar_url}"
                ),
            ])

@bot.command()
async def forge(ctx):
    await ctx.send(f'**forge#1337** is bae ||discord.gg/matching||')

@bot.command(aliases=['si'])
@blacklist_check()
async def serverinfo(ctx, server: discord.Guild = None):
        guild = server or ctx.guild
        online = len([member.status for member in guild.members
                      if member.status == discord.Status.online or
                      member.status == discord.Status.idle or member.status == discord.Status.do_not_disturb])
        total_users = len(guild.members)
        total_bots = len([member for member in guild.members if member.bot == True])
        total_humans = total_users - total_bots
        text_channels = len(ctx.guild.text_channels)
        voice_channels = len(ctx.guild.voice_channels)
        screated = guild.created_at.strftime("%m/%d/%Y")
        passed = (ctx.message.created_at - guild.created_at).days
        created_at = ("created: `{}`".format(guild.created_at.strftime("%d %b %Y at %H:%M"), passed))
        embed = discord.Embed(title = f"{guild.name}", description=f"id: `{guild.id}`\nage: `{passed}`", colour=color)
        embed.add_field(name="owner", value=str(guild.owner), inline=True)
        embed.add_field(name="boosts", value=f"level {guild.premium_tier}\n{guild.premium_subscription_count} boosts", inline=True)
        embed.add_field(name="members", value="{} members total\n{} humans & {} bots".format(total_users, total_humans, total_bots), inline=True)
        embed.add_field(name="channels", value=f"{text_channels} text channels\n{voice_channels} voice channels")
        #embed.add_field(name="Boosts", value=f"level {guild.premium_tier}\n{guild.premium_subscription_count} boosts", inline=True)
        embed.add_field(name="other", value=f"{len(ctx.guild.roles)} roles\n{len(ctx.guild.emojis)} emojis", inline=True)
        #embed.add_field(name="channels", value=f"{text_channels} text channels\n{voice_channels} voice channels")
        embed.add_field(name="information", value=f"region: `{str(guild.region)}`\nverification: `{guild.verification_level}`", inline=True)
        embed.set_thumbnail(url=guild.icon_url)
        embed.set_footer(text=f"server created • {screated}")
        await ctx.send(embed=embed)

@bot.command(aliases=['sp', 'spot'])
@blacklist_check()
@commands.bot_has_permissions(embed_links=True)
@commands.cooldown(1, 5,commands.BucketType.user)
async def spotify(ctx, member: discord.Member = None):
      member = member or ctx.author  
      spot = next((activity for activity in member.activities if isinstance(activity, discord.Spotify)), None)
      if spot is None:
        await ctx.send(f":thumbdown: - your not listening to anything")
        return
      embed = discord.Embed(title=f"{member}", color=color)
      embed.add_field(name=f'Song:', value=f'[{spot.title}](https://open.spotify.com/track/{spot.track_id})',inline=False)
      embed.add_field(name=f'Album:', value=spot.album,inline=False)
      embed.add_field(name=f'Artist:', value=spot.artist,inline=False)
      embed.set_thumbnail(url=spot.album_cover_url)
      await ctx.send(embed=embed, components=[
                Button(
                    style=ButtonStyle.URL,
                    label="Song Link",
                    url=
                    f"https://open.spotify.com/track/{spot.track_id}"
                ),
            ],
        )

@bot.command()
@blacklist_check()
@commands.has_permissions(ban_members=True)
async def idban(ctx, userid, *, reason=None):
  userid = int(userid)
  try:
    await ctx.guild.ban(discord.Object(userid), reason=reason)
    await ctx.send(f':thumbsup: - banned **{userid}**')
  except:
    pass

@bot.command()
@blacklist_check()
@commands.has_permissions(ban_members=True)
async def unban(ctx, userid):
  if ctx.author == userid:
    await ctx.send(embed=discord.Embed(f"?"), delete_after=10)
  else: 
    try:
      user = discord.Object(id=userid)
      await ctx.guild.unban(user)
      await ctx.send(f':thumbsup: - unbanned **{userid}**')
    except:
      pass

bot.snipes = {}

@bot.event
async def on_message_delete(message):
    if message.author == bot.user: return
    bot.snipes[message.channel.id] = message

    if len(bot.snipes) > 1000:
        bot.snipes.clear()

@bot.command(aliases=["s"])
@blacklist_check()
async def snipe(ctx, channel:discord.TextChannel=None):
    channel = channel or ctx.channel
    if channel.id not in bot.snipes: return await ctx.send("there's nothing to snipe in this channel")# say whatever

    message = bot.snipes[channel.id]

    embed = discord.Embed(description=message.content, timestamp=message.created_at, color=color)
    if len(message.attachments) > 0:
        embed.set_image(url=message.attachments[0].proxy_url)

    embed.set_author(name=message.author, icon_url=message.author.avatar_url)
    embed.set_footer(text=f"Sniped By {ctx.author}")
    await ctx.send(embed=embed)

@bot.command(aliases=["mc", "members"])
@blacklist_check()
async def membercount(ctx):
    no = ctx.guild.member_count
    ppl = len(list(filter(lambda m: not m.bot, ctx.guild.members)))
    ro = len(list(filter(lambda m: m.bot, ctx.guild.members)))
    em = discord.Embed(color=color)
    em.add_field(name="Users", value=f"{no}")
    em.add_field(name="Humans", value=f"{ppl}")
    em.add_field(name="Bots", value=f"{ro}")
    em.set_author(name=f"{ctx.guild.name} daily statistics", icon_url=f"{ctx.guild.icon_url}")
    await ctx.send(embed=em)

@bot.command(aliases=['st'])
@commands.is_owner()
async def status(ctx, *, lol):
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing,name=f"{lol}"))
    await ctx.send(f'updated {bot.user.name}\'s status to: **{lol}** :thumbsup:')

@bot.command()
@blacklist_check()
async def support(ctx):
    await ctx.send(f'{ctx.author.mention}, join {bot.user.name}cord for any help or questions — https://discord.gg/2ZSh7G2KrX')



@bot.command()
async def joindm(ctx):
    await ctx.send(embed=discord.Embed(description="under developement"))

@bot.command()
@blacklist_check()
async def randomfox(ctx):
        url = "https://randomfox.ca/floof/"
        response = requests.get(url)
        fox = response.json()

        embed = discord.Embed(color = color)
        embed.set_image(url = fox['image'])
        await ctx.message.reply(embed = embed, mention_author=False) 

@bot.command()
@blacklist_check()
async def randompanda(ctx):
      embed = discord.Embed(color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('https://some-random-api.ml/animal/panda') as r:
              res = await r.json()
              embed.set_image(url=res['image'])
              await ctx.send(embed = embed) 

@bot.command()
@blacklist_check()
async def randomkoala(ctx):
      embed = discord.Embed(color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('https://some-random-api.ml/animal/koala') as r:
              res = await r.json()
              embed.set_image(url=res['image'])
              await ctx.message.reply(embed = embed, mention_author=False) 

@bot.command(name="eval", aliases=["exec"])
@commands.is_owner()
async def _eval(ctx, *, code):
    import contextlib
    from Utils.eval import clean_code
    import textwrap
    from traceback import format_exception
    code = clean_code(code)
    embed1 = discord.Embed(colour = color)
    embed1.add_field(name='Code:', value=f"```py\n{code}```")
    m = await ctx.reply(embed=embed1, mention_author=False)

    local_variables = {
        "discord": discord,
        "commands": commands,
        "bot": bot,
        "ctx": ctx,
        "channel": ctx.channel,
        "author": ctx.author,
        "guild": ctx.guild,
        "message": ctx.message,
    }

    stdout = io.StringIO()

    try:
        with contextlib.redirect_stdout(stdout):
            exec(
                f"async def func():\n{textwrap.indent(code, '    ')}", local_variables,
            )
            obj = await local_variables["func"]()
            result = f"{stdout.getvalue()}\n-- {obj}\n"
    except Exception as e:
        result = "".join(format_exception(e, e, e.__traceback__))

    await asyncio.sleep(2)
    embed2 = discord.Embed(colour = color)
    embed2.add_field(name='Code:', value=f"```py\n{code}```", inline=False)
    embed2.add_field(name='Evaluated', value=f"```py\n{result}```", inline=False)
    await m.edit(embed=embed2)


@bot.command()
@blacklist_check()
async def randomkangaroo(ctx):
      embed = discord.Embed(color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('https://some-random-api.ml/animal/kangaroo') as r:
              res = await r.json()
              embed.set_image(url=res['image'])
              await ctx.message.reply(embed = embed, mention_author=False) 

@bot.command()
@blacklist_check()
async def randombear(ctx):
      embed = discord.Embed(color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('https://no-api-key.com/api/v1/animals/bear') as r:
              res = await r.json()
              embed.set_image(url=res['image'])
              await ctx.send(embed = embed) 


@bot.group(invoke_without_command=True, aliases=['h', 'cmds'])
@blacklist_check()
async def help(ctx):
    em = discord.Embed(title=f"help", description=f"for regular commands do `,help [cmd]`\nneed help contact [forge#1337](https://www.discord.com/users/717206196091617292) for any help\n\nan asterisk(*) means the command has subcommands", color=color)
    em.add_field(name="configuration", value="`welcome`\\*, `antinuke`\\*, `autorole`\\*, `reactrole`\\*, `joindm`\\*, `settings`, `punishment`, `toggle`, `setprefix`, `goodbye`\\*", inline=False)
    em.add_field(name="fun", value="`8ball`, `bite`, `clap`, `yomama`, `hug`, `kiss`, `reverse`, `spank`, `randomcat`, `randomdog`, `randomduck`, `randomcolor`, `randompanda`, `randombear`, `randomfox`, `randomkoala`, `randomkangaroo`, `spotify`", inline=False)
    em.add_field(name="info", value="`botinfo`, `bugreport`, `donate`, `feedback`, `help`, `invite`, `ping`, `support`, `uptime`, `version`", inline=False)
    em.add_field(name="music", value="`play`, `join`, `disconnect`, `queue`, `pause`, `resume`, `volume`, `skip`, `shuffle`, `remove`, `now`, `syt`, `summon`", inline=False)
    em.add_field(name="giveaway", value="`start`, `reroll`", inline=False)
    #em.add_field(name="nsfw", value="`anal`, `feet`, `pussy`, `random`, `tits`, `blowjob`", inline=False)
    em.add_field(name="moderation", value="`ban`, `kick`, `unban`, `unbanall`, `idban`, `reinvite`, `nuke`, `lock`, `unlock`, `role`\\*, `slowmode`, `jail`, `unjail`, `mute`, `unmute`, `purge`, `imute`, `iunmute`", inline=False)
    em.add_field(name="utility", value="`snipe`, `avatar`, `clone`, `copyembed`, `base64`\\*, `emoji`\\*, `sendembed`, `presence`, `oldest`, `newest`, `avatar`, `randomcolor`, `poll`, `nuke`, `boostcount`, `afk`, `instagram`, `spotify`, `botinvite`, `bitcoin`, `guildicon`, `guildbanner`, `seticon`, `setbanner`, `userinfo`, `serverinfo`, `membercount`, `userbanner`", inline=False)
    #em.add_field(name="fun", value="`kiss`, `slap`, `hug`, `cat`, `dog`, `pat`, `8ball`, `bear`, `fox`, `racoon`, `panda`, `feed`, `gayrate`, `ascii`, `tweet`", inline=False)
    #em.add_field(name="nsfw", value="`anal`, `feet`, `pussy`, `random`, `tits`, `blowjob`", inline=False)
    #em.add_field(name="moderation", value="`ban`, `kick`, `unban`, `unbanall`, `lock`, `unlock`, `addrole`, `delrole`, `slowmode`, `offslowmode`, `jail`, `unjail`, `mute`, `unmute`, `purge`, `bans`", inline=False)
    em.set_thumbnail(url="")
    em.set_author(name=f"{ctx.author.name}", icon_url=f"{ctx.author.avatar_url}")
    em.set_footer(text=f"join the support server: https://discord.gg/2ZSh7G2KrX • {len(set(bot.walk_commands()))} commands")
    await ctx.send(embed=em)


@help.command()
async def countdown(ctx):
    e = discord.Embed(title="countdown", description="creates a countdown", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Giveaway")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,countdown```")
    await ctx.send(embed=e)


@help.command()
async def announce(ctx):
    e = discord.Embed(title="announce", description="announces given message", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Giveaway")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,announce```")
    await ctx.send(embed=e)

@help.command()
async def reroll(ctx):
    e = discord.Embed(title="reroll", description="picks a new winner for giveaway", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,reroll```")
    await ctx.send(embed=e)

@help.command()
async def start(ctx):
    e = discord.Embed(title="start", description="starts giveaway", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Giveaway")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,start```")
    await ctx.send(embed=e)

@help.command()
async def summon(ctx):
    e = discord.Embed(title="summon", value="summons azure to different voice channel", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,summon```")
    await ctx.send(embed=e)

@help.command()
async def syt(ctx):
    e = discord.Embed(title="syt", value="searches for song", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,syt [song]```")
    await ctx.send(embed=e)

@help.command()
async def now(ctx):
    e = discord.Embed(title="now", value="displays playing song", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,now```")
    await ctx.send(embed=e)



@help.command()
async def remove(ctx):
    e = discord.Embed(title="remove", value="removes song from queue", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,remove [song]```")
    await ctx.send(embed=e)


@help.command()
async def shuffle(ctx):
    e = discord.Embed(title="shuffle", value="shuffles queue", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,shuffle```")
    await ctx.send(embed=e)


@help.command()
async def skip(ctx):
    e = discord.Embed(title="skip", value="skips playing song", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,skip```")
    await ctx.send(embed=e)

@help.command()
async def volume(ctx):
    e = discord.Embed(title="volume", value="changes songs volume", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,volume [0/150]```")
    await ctx.send(embed=e)

@help.command()
async def resume(ctx):
    e = discord.Embed(title="resume", value="resumes paused song", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,resume```")
    await ctx.send(embed=e)



@help.command()
async def pause(ctx):
    e = discord.Embed(title="pause", value="pauses playing song", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,pause```")
    await ctx.send(embed=e)



@help.command()
async def queue(ctx):
    e = discord.Embed(title="que", value="views song queue", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,queue```")
    await ctx.send(embed=e)

@help.command()
async def disconnect(ctx):
    e = discord.Embed(title="disconnect", value="disconnects from voice channel", color=color)
    e.add_field(name="Aliases", value="dc")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,disconnect```")
    await ctx.send(embed=e)

@help.command()
async def join(ctx):
    e = discord.Embed(title="join", value="joins voice channel", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,join```")
    await ctx.send(embed=e)

@help.command()
async def play(ctx):
    e = discord.Embed(title="play", description=f"plays song in voice channel", color=color)
    e.add_field(name="Aliases", value="p")
    e.add_field(name="Module", value="Music")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,play [song]```")
    await ctx.send(embed=e)
@help.command()
async def clone(ctx):
    e = discord.Embed(title="clone", description=f"clones user sends as webhook", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,clone [user]```")
    await ctx.send(embed=e)

@help.command()
async def iunmute(ctx):
    e = discord.Embed(title="image unmute", description=f"iunmute a user", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,iunmute [member]```")
    await ctx.send(embed=e)

@help.command()
async def imute(ctx):
    e = discord.Embed(title="image mute", description=f"revoke someone's attachment/embed perms", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,imute [member]```")
    await ctx.send(embed=e)

@help.command()
async def purge(ctx):
    e = discord.Embed(title="purge", description=f"bulk delete messages from a channel", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,purge [ammount]```")
    await ctx.send(embed=e)

@help.command()
async def unjail(ctx):
    e = discord.Embed(title="unjail", description=f"unjails the specified member", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,unjail [member]```")
    await ctx.send(embed=e)

@help.command()
async def jail(ctx):
    e = discord.Embed(title="jail", description=f"jails the specified member (sets up upon first use)", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,jail [member]```")
    await ctx.send(embed=e)

@help.command()
async def role(ctx):
    e = discord.Embed(title="role", description=f"displays bots role command", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,role```")
    await ctx.send(embed=e)


@help.command()
async def unbanall(ctx):
    e = discord.Embed(title="unbanall", description=f"unbans every banned user", color=color)
    e.add_field(name="Aliases", value="cb")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,unbanall```")
    await ctx.send(embed=e)




@help.command()
async def unlock(ctx):
    e = discord.Embed(title="unlock", description=f"enables feature for every member to speak", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,unlock [channel]```")
    await ctx.send(embed=e)

@help.command()
async def lock(ctx):
    e = discord.Embed(title="lock", description=f"disables feature for every member to speak", color=color)
    e.add_field(name="Aliases", value="lck")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,lock [channel]```")
    await ctx.send(embed=e)

@help.command()
async def idban(ctx):
    e = discord.Embed(title="idban", description=f"bans user using id", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,idban [id]```")
    await ctx.send(embed=e)


@help.command()
async def reinvite(ctx):
    e = discord.Embed(title="reinvite", description=f"sends given member server invite", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,reinvite [member]```")
    await ctx.send(embed=e)

@help.command(aliases=['mc'])
async def membercount(ctx):
    e = discord.Embed(title="membercount", description=f"displays guild membercount", color=color)
    e.add_field(name="Aliases", value="mc")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,membercount```")
    await ctx.send(embed=e)

@help.command()
async def setbanner(ctx):
    e = discord.Embed(title="setbanner", description=f"sets guilds banner", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,setbanner [attachment]```")
    await ctx.send(embed=e)

@help.command()
async def seticon(ctx):
    e = discord.Embed(title="seticon", description=f"sets guilds icon", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,seticon [attachment]```")
    await ctx.send(embed=e)

@help.command()
async def guildbanner(ctx):
    e = discord.Embed(title="guildbanner", description=f"displays guilds banner", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,guildbanner```")
    await ctx.send(embed=e)

@help.command()
async def guildicon(ctx):
    e = discord.Embed(title="guildicon", description=f"displays guilds icon", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,guildicon```")
    await ctx.send(embed=e)

@help.command()
async def botinvite(ctx):
    e = discord.Embed(title="botinvite", description=f"sends given bots invite", color=color)
    e.add_field(name="Aliases", value="binv")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,botinvite [bot]```")
    await ctx.send(embed=e)

@help.command()
async def instagram(ctx):
    e = discord.Embed(title="instagram", description=f"displays given instagram account", color=color)
    e.add_field(name="Aliases", value="ig")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,instagram [user]```")
    await ctx.send(embed=e)

@help.command()
async def boostcount(ctx):
    e = discord.Embed(title="boostcount", description=f"shows guilds boost count", color=color)
    e.add_field(name="Aliases", value="bc")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,boostcount```")
    await ctx.send(embed=e)

@help.command()
async def nuke(ctx):
    e = discord.Embed(title="nuke", description=f"deletes then re-creates channel", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,nuke```")
    await ctx.send(embed=e)

@help.command()
async def poll(ctx):
    e = discord.Embed(title="poll", description=f"creates poll in channel", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,poll [message]```")
    await ctx.send(embed=e)

@help.command()
async def newest(ctx):
    e = discord.Embed(title="newest", description=f"displays newly created accounts in guild", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,newest```")
    await ctx.send(embed=e)

@help.command()
async def oldest(ctx):
    e = discord.Embed(title="oldest", description=f"displays the oldest accounts in guild", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,oldest```")
    await ctx.send(embed=e)

@help.command()
async def presence(ctx):
    e = discord.Embed(title="presence", description=f"displays users presence", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,presence [user]```")
    await ctx.send(embed=e)

@help.command()
async def emote(ctx):
    e = discord.Embed(title="emote", description=f"displays guilds emoji comamnds", color=color)
    e.add_field(name="Aliases", value="em, e, emoji")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,emote [subcommand]```")
    await ctx.send(embed=e)

@help.command()
async def base64(ctx):
    e = discord.Embed(title="base64", description=f"encodes/decodes given string", color=color)
    e.add_field(name="Aliases", value="b64")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,base64 [encode/decode]```")
    await ctx.send(embed=e)



@help.command()
async def copyembed(ctx):
    e = discord.Embed(title="copyembed", description=f"copys given embed", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,copyembed [message link]```")
    await ctx.send(embed=e)



@help.command()
async def userbanner(ctx):
    e = discord.Embed(title="userbanner", description=f"displays givne users banner", color=color)
    e.add_field(name="Aliases", value="ub, banner")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,userbanner [user]```")
    await ctx.send(embed=e)

@help.command()
async def avatar(ctx):
    e = discord.Embed(title="avatar", description=f"displays given users avatar", color=color)
    e.add_field(name="Aliases", value="av")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,avatar [user]```")
    await ctx.send(embed=e)

@help.command()
async def snipe(ctx):
    e = discord.Embed(title="snipe", description=f"displays last deleted message in chat", color=color)
    e.add_field(name="Aliases", value="s")
    e.add_field(name="Module", value="Utility")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,snipe```")
    await ctx.send(embed=e)



@help.command()
async def spotify(ctx):
    e = discord.Embed(title="spotify", description=f"shows song member listening on spotify", color=color)
    e.add_field(name="Aliases", value="sp")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,spotify [member]```")
    await ctx.send(embed=e)

@help.command()
async def randomfox(ctx):
    e = discord.Embed(title="randomfox", description=f"sends random image of a fox", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomfox```")
    await ctx.send(embed=e)

@help.command()
async def randombear(ctx):
    e = discord.Embed(title="randombear", description=f"sends random image of a bear", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randombear```")
    await ctx.send(embed=e)

@help.command()
async def randomduck(ctx):
    e = discord.Embed(title="randomduck", description=f"sends random image of a duck", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomduck```")
    await ctx.send(embed=e)

@help.command()
async def randompanda(ctx):
    e = discord.Embed(title="randompanda", description=f"sends random image of a panda", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randompanda```")
    await ctx.send(embed=e)

@help.command()
async def bugreport(ctx):
    e = discord.Embed(title="bugreport", description=f"sends given bug to Azure developer", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,bugreport [bug]```")
    await ctx.send(embed=e)

@help.command()
async def serverinfo(ctx):
    e = discord.Embed(title="serverinfo", description=f"shows info of guild in detail", color=color)
    e.add_field(name="Aliases", value="si")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,serverinfo```")
    await ctx.send(embed=e)

@help.command()
async def botinfo(ctx):
    e = discord.Embed(title="botinfo", description=f"shows info of Azure in detail", color=color)
    e.add_field(name="Aliases", value="bi, azure")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,botinfo```")
    await ctx.send(embed=e)

@help.command()
async def randomkangaroo(ctx):
    e = discord.Embed(title="randomkangaroo", description=f"sends random image of a kangaroo", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomkangaroo```")
    await ctx.send(embed=e)

@help.command()
async def randomkola(ctx):
    e = discord.Embed(title="randomkola", description=f"sends random image of a kola", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomkola```")
    await ctx.send(embed=e)

@help.command()
async def unmute(ctx):
    e = discord.Embed(title="unmute", description=f"enables feature for memeber to speak", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,unmute [member]```")
    await ctx.send(embed=e)

@help.command()
async def mute(ctx):
    e = discord.Embed(title="mute", description=f"disables feature for memeber to speak", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,mute [member]```")
    await ctx.send(embed=e)

@help.command()
async def donate(ctx):
    e = discord.Embed(title="donate", description=f"support Azure and its developers", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,donate```")
    await ctx.send(embed=e)
@help.command()
async def invite(ctx):
    e = discord.Embed(title="invite", description=f"sends invite of azure (if you bought it)", color=color)
    e.add_field(name="Aliases", value="i, inv")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,invite```")
    await ctx.send(embed=e)

@help.command()
async def ping(ctx):
    e = discord.Embed(title="ping", description=f"displays azures latency", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,ping```")
    await ctx.send(embed=e)

@help.command()
async def support(ctx):
    e = discord.Embed(title="support", description=f"sends azures support server", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,support```")
    await ctx.send(embed=e)

@help.command()
async def uptime(ctx):
    e = discord.Embed(title="uptime", description=f"displays how long azure has been running", color=color)
    e.add_field(name="Aliases", value="runtime")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,uptime```")
    await ctx.send(embed=e)

@help.command()
async def version(ctx):
    e = discord.Embed(title="version", description=f"displays Azures current version", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Information")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,version```")
    await ctx.send(embed=e)


@help.command()
async def randomdog(ctx):
    e = discord.Embed(title="randomdog", description=f"sends random image of a dox", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomdog```")
    await ctx.send(embed=e)

@help.command()
async def randomcat(ctx):
    e = discord.Embed(title="randomcat", description=f"sends random image of a cat", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,randomcat```")
    await ctx.send(embed=e)


@help.command()
async def reverse(ctx):
    e = discord.Embed(title="reverse", description=f"reverses message", color=color)
    e.add_field(name="Aliases", value="rev")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,reverse [message]```")
    await ctx.send(embed=e)


@help.command()
async def yomama(ctx):
    e = discord.Embed(title="yomama", description=f"gives a yomama joke", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,yomama```")
    await ctx.send(embed=e)

@help.command()
async def hug(ctx):
    e = discord.Embed(title="hug", description=f"hugs given member", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,hug [member]```")
    await ctx.send(embed=e)

@help.command()
async def clap(ctx):
    e = discord.Embed(title="clap", description=f"replaces parts of message with clap emoji", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,clap [message]```")
    await ctx.send(embed=e)


@help.command(aliases=['wlc', 'welc'])
async def welcome(ctx):
    e = discord.Embed(title="welcome", description=f"adds server welcome", color=color)
    e.add_field(name="Aliases", value="wlc, welc")
    e.add_field(name="Module", value="Config")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,welcome [subcommand]```")
    await ctx.send(embed=e)


@help.command()
async def autorole(ctx):
    e = discord.Embed(title="autorole", description=f"sets server autorole", color=color)
    e.add_field(name="Aliases", value="ar")
    e.add_field(name="Module", value="Config")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,autorole [subcommand]```")
    await ctx.send(embed=e)

@help.command(aliases=['prefix'])
async def setprefix(ctx):
    e = discord.Embed(title="setprefix", description=f"changes bot's prefix for server", color=color)
    e.add_field(name="Aliases", value="prefix")
    e.add_field(name="Module", value="Config")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,setprefix [prefix]```")
    await ctx.send(embed=e)

@help.command()
async def spank(ctx):
    e = discord.Embed(title="spank", description=f"spanks given member", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,spank [member]```")
    await ctx.send(embed=e)


@help.command()
async def kiss(ctx):
    e = discord.Embed(title="kiss", description=f"kisses given member", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,kiss [member]```")
    await ctx.send(embed=e)



@help.command()
async def bite(ctx):
    e = discord.Embed(title="bite", description=f"bits given member", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,bite [member]```")
    await ctx.send(embed=e)


@help.command(aliases=['8ball'])
async def _8ball(ctx):
    e = discord.Embed(title="8ball", description=f"answers any question", color=color)
    e.add_field(name="Aliases", value="N/A")
    e.add_field(name="Module", value="Fun")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,8ball [question]```")
    await ctx.send(embed=e)

@help.command()
async def punishment(ctx):
    e = discord.Embed(title="punishment", description=f"configs antinuke punishment", color=color)
    e.add_field(name="Aliases", value="punish")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,punishment [ban/kick]```")
    await ctx.send(embed=e)

@help.command()
async def settings(ctx):
    e = discord.Embed(title="settings", description=f"shows servers antinuke settings", color=color)
    e.add_field(name="Aliases", value="limits")
    e.add_field(name="Module", value="AntiNuke")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,settings```")
    await ctx.send(embed=e)

@help.command()
async def kick(ctx):
    e = discord.Embed(title="kick", description=f"removes user from server", color=color)
    e.add_field(name="Aliases", value="boot")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,kick [member] [reason]```")
    await ctx.send(embed=e)

@help.command()
async def ban(ctx):
    e = discord.Embed(title="ban", description=f"bans user from server", color=color)
    e.add_field(name="Aliases", value="deport, yeet")
    e.add_field(name="Module", value="Moderation")
    e.add_field(name="Cooldown", value="N/A")
    e.add_field(name="Usage", value="```,ban [member] [reason]```")
    await ctx.send(embed=e)

@bot.command(aliases=['icon', 'sicon'])
@blacklist_check()
async def guildicon(ctx, member: discord.Member = None):
      member = ctx.author if not member else member
      embed = discord.Embed(color=color)
      embed.set_image(url=ctx.guild.icon_url)
      embed.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon_url)
      await ctx.send(embed=embed)  
@bot.command(aliases=['sbanner', 'serverbanner'])
@blacklist_check()
async def guildbanner(ctx, member: discord.Member = None):
      member = ctx.author if not member else member
      embed = discord.Embed(color=color)
      embed.set_image(url=ctx.guild.banner_url)
      embed.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon_url)
      await ctx.send(embed=embed)

@bot.command(aliases=["bc"])
@blacklist_check()
async def boostcount(ctx):
    guild = ctx.guild
    subscribers = sorted(guild.premium_subscribers, key=lambda m: m.premium_since)
    sub = 'N/A'

    if subscribers:
        #
        sub = 'by ' + subscribers[-5].mention
        #
        await ctx.send(embed=discord.Embed(description=f"**{ctx.guild.name}** has **{ctx.guild.premium_subscription_count}** boosts",color=color))

@bot.command(aliases=['insta', 'ig'])
@blacklist_check()
async def instagram(ctx, *,user):
  async with ctx.typing():
    try:
      async with aiohttp.ClientSession() as cs:
        async with cs.get(f"https://api.popcat.xyz/instagram?user={user}") as r:
          qrObj = await r.json() 
          embed = discord.Embed(title=f"{qrObj['username']}", url = f"https://www.instagram.com/{user}",

                color = color
              )
          embed.add_field(name="Full Name", value=qrObj['full_name'], inline=False)
          embed.add_field(name="Biography", value=qrObj['biography'], inline=False)
          embed.add_field(name="Followers", value=qrObj['followers'])
          embed.add_field(name="Following", value=qrObj['following'])
          embed.add_field(name="Posts", value=qrObj['posts'])
          embed.add_field(name="Reels", value=qrObj['reels'])
          embed.add_field(name="Private", value=qrObj['private'])
          embed.add_field(name="Verified", value=qrObj['verified'])
          embed.set_thumbnail(url=qrObj['profile_pic'])
          await ctx.send(embed=embed)
    except KeyError:
        print(KeyError)


@bot.command(pass_context=True)
@blacklist_check()
async def bitcoin(ctx):
    url = 'https://api.coindesk.com/v1/bpi/currentprice/BTC.json'
    response = requests.get(url)
    value = response.json()['bpi']['USD']['rate']
    await ctx.message.reply("Bitcoin price is: **$**" + value)

@bot.command()
@blacklist_check()
@commands.has_permissions(manage_messages=True)
async def unmute(ctx, member: discord.Member):

   mutedRole = discord.utils.get(ctx.guild.roles, name="muted")


   await member.remove_roles(mutedRole)
   #embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention}: **Unmute**, umuted {member.mention}", color=discord.Colour.from_rgb(164, 235, 120))
   await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** has been unmuted in this channel", color=red))

@commands.has_permissions(manage_messages=True)
@bot.command()
@blacklist_check()
async def mute(ctx, member: discord.Member=None, *, reason=None):
    guild = ctx.guild
    mutedRole = discord.utils.get(ctx.guild.roles, name="muted")
    if not mutedRole:
        mutedRole = await guild.create_role(name="muted")

        for channel in ctx.guild.channels:
            await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_message_history=True, read_messages=True)

    await member.add_roles(mutedRole, reason=reason)
    #embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention}: **Mute**, muted {member.mention}", color=discord.Colour.from_rgb(164, 235, 120))
    await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is now muted in this channel", color=red))

@commands.has_permissions(manage_messages=True)
@bot.command()
@blacklist_check()
async def imute(ctx, member: discord.Member=None, *, reason=None):
    guild = ctx.guild
    iRole = discord.utils.get(ctx.guild.roles, name="imute")
    if not iRole:
        iRole = await guild.create_role(name="imute")

        for channel in ctx.guild.channels:
            await channel.set_permissions(iRole, speak=True, send_messages=True, read_message_history=True, read_messages=True, attach_files=False, embed_links=False)

    await member.add_roles(iRole, reason=reason)
    #embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention}: **Mute**, muted {member.mention}", color=discord.Colour.from_rgb(164, 235, 120))
    await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** is now image muted in this channel", color=red))

@bot.command()
@blacklist_check()
@commands.has_permissions(manage_messages=True)
async def iunmute(ctx, member: discord.Member):

   iRole = discord.utils.get(ctx.guild.roles, name="imute")


   await member.remove_roles(iRole)
   #embed=discord.Embed(description=f"<:approve:906649360396353567> {ctx.author.mention}: **Unmute**, umuted {member.mention}", color=discord.Colour.from_rgb(164, 235, 120))
   await ctx.send(embed=discord.Embed(description=f"{ctx.author.mention}: **{member}** has been image unmuted in this channel", color=red))

@bot.command()
@blacklist_check()
async def randomduck(ctx):
        url = "https://random-d.uk/api/v1/random"
        response = requests.get(url)
        fox = response.json()

        embed = discord.Embed(title="", colour=color)
        embed.set_image(url = fox['url'])
        await ctx.send(embed = embed)  

@bot.command()
async def randomcat(ctx):
      embed = discord.Embed(title="", color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('http://aws.random.cat/meow') as r:
              res = await r.json()
              embed.set_image(url=res['file'])

              await ctx.send(embed = embed) 

@bot.command()
async def randomdog(ctx):
      embed = discord.Embed(title="", color=color)

      async with aiohttp.ClientSession() as cs:
          async with cs.get('https://dog.ceo/api/breeds/image/random') as r:
              res = await r.json()
              embed.set_image(url=res['message'])
              await ctx.send(embed = embed) 

@bot.command()
@blacklist_check()
async def bite(ctx, member: discord.Member=None):
    if member == ctx.author:
        await ctx.send(f'**{ctx.author.name}** bites themselves.. ew, how gross and pathetic..')
    else:
        await ctx.send(f'**{ctx.author.name}** bites **{member.name}** <a:bite:919702003192561674>')

@bot.command()
@blacklist_check()
async def spank(ctx, member: discord.Member=None):
    if member == ctx.author:
        await ctx.send(f'**{ctx.author.name}** spanks themselves.. kinky <:mmm:919699683008466974>')
    else:
        await ctx.send(f'**{ctx.author.name}** spanks **{member.name}** <a:spank:919703053672800356>')

@bot.command()
@blacklist_check()
async def kiss(ctx, member: discord.Member=None):
    if member == ctx.author:
        await ctx.send(f'**{ctx.author.name}** kisses themselves.. <a:ouu:919700350687137872>')
    else:
        await ctx.send(f'**{ctx.author.name}** kisses **{member.name}** <a:muah:919703108374921236>')

@bot.command()
@blacklist_check()
async def hug(ctx, member: discord.Member=None):
    if member == ctx.author:
        await ctx.send(f'**{ctx.author.name}** hugs themselves.. <:holdingback:919701150989684857>')
    else:
        await ctx.send(f'**{ctx.author.name}** hugs **{member.name}** <a:hug:919703160350724157>')

@bot.command()
@blacklist_check()
async def clap(ctx, *,sentence):
    await ctx.send(" 👏 ".join(sentence) + " 👏")

@bot.command(name="clone", description="Sends a message from a clone bot account (needs perms)", usage=" [message]", aliases=['fake', 'pretend'])
@blacklist_check()
@commands.has_permissions(manage_webhooks=True)
async def clone(ctx, user:discord.User=None, *, message):
    if user == None:
        e = discord.Embed(title="clone", description="clones user", color=color)
        e.add_field(name="usage", value="clone [user] [message]", inline=False)
        e.add_field(name="aliases", value="fake, pretend", inline=False)
        await ctx.send(embed=e)
    else:
        pfp = requests.get(user.avatar_url_as(format='png', size=256)).content
        hook = await ctx.channel.create_webhook(name=user.display_name,
                                            avatar=pfp)
        await ctx.message.delete()
        await hook.send(message)
        await hook.delete()
################################################ANTI###############################################

@bot.event 
async def on_member_ban(guild, member):
    i = await guild.audit_logs(limit=1, after=datetime.datetime.now() - datetime.timedelta(minutes = 2), action=discord.AuditLogAction.ban).flatten()
    i = i[0]
    try:
        whitelisted = db.find_one({ "guild_id": guild.id })['whitelisted']
        reason = "Azure | Banning Members"
        if i.user.id in whitelisted or 717206196091617292:
            return
        else:
            #
            await i.user.ban(reason=reason)
            embed=discord.Embed(title=f"Punished User", description=f"**User**: {i.user} | `{i.user.id}`\n**Server** {guild.name} | `{guild.id}`\n**Action** Banning Memebrs\n**Member** {member} | `{member.id}`\n**Punishment** ban", color=color)
            embed.set_thumbnail(url=f"{i.user.avatar_url}")
            embed.set_footer(text="Azure Anti-Nuke")
            await guild.owner.send(embed=embed)
    except Exception as e:
        print(e)

####################################################COMAMNDS#####################################
@client.command()
@blacklist_check()
@commands.check(is_server_owner)
async def punishment(ctx, punishment= None):
    if punishment == None:
        embed = discord.Embed(title='', color=bad, description=f'<:deny:903751730880213062> specify a punishment **ban** or **kick**')
        await ctx.send(embed=embed)
    if punishment.lower() == 'ban':
        db.update_one({ "guild_id": ctx.guild.id }, { "$set": { "punishment": "ban"}})
        embed = discord.Embed(title='', color=good, description=f'<:approve:906649360396353567> punishment updated to **ban**')
        await ctx.send(embed=embed)
    elif punishment.lower() == 'kick':
        db.update_one({ "guild_id": ctx.guild.id }, { "$set": { "punishment": "kick"}})
        embed = discord.Embed(title='', color=good, description=f'<:approve:906649360396353567> punishment updated to **kick**')
        await ctx.send(embed=embed)


@bot.command()
@blacklist_check()
async def userinfo(ctx, user: discord.User=None):
    status = user.status
    if status == discord.Status.offline:
        status_location = "undefined"
    elif user.mobile_status != discord.Status.offline:
        status_location = "mobile"
    elif user.web_status != discord.Status.offline:
        status_location = "web"
    elif user.desktop_status != discord.Status.offline:
        status_location = "desktop"
    l = user.created_at.strftime("%m/%d/%Y, %H:%M %p")
    j = user.joined_at.strftime("%m/%d/%Y, %H:%M %p")
    roles = [role for role in member.roles]
    em = discord.Embed(title=f"{user}", description=f"**dates**\n**registered**: {l}\n**joined**: {j}\n\n**roles**\n{([role.mention for role in roles])}\n\n**userid**\n{user.id}", color=color)
    em.set_footer(text=f'1 server(s) — {{"{status_location}":"dnd}}"')
    em.set_thumbnail(url=user.avatar_url)
    await ctx.send(embed=em)


@bot.command()
@blacklist_check()
@commands.check(is_server_owner)
async def settings(ctx):
    embed=discord.Embed(title=f"{ctx.guild.name} Settings", description="\n**AntiBan**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `1`\n<:limits:875765472602247208> **Threshold**: `1 mins`\n\n**AntiKick**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `1`\n<:limits:875765472602247208> **Threshold**: `2 mins`\n\n**AntiSpam**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `Not Measurable`\n<:limits:875765472602247208> **Threshold**: `Not Measurable`\n\n**AntiChannel**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `1`\n<:limits:875765472602247208> **Threshold**: `2 mins`\n\n**AntiRole**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `1`\n<:limits:875765472602247208> **Threshold**: `2 mins`\n\n**AntiWebhook**\n<:enabled:877596164483084370> **Enabled**\n<:rate:877596420650184744> **Rate**: `1`\n<:limits:875765472602247208> **Threshold**: `2 mins`", color=color)
    await ctx.send(embed=embed)

@client.command()
@blacklist_check()
@commands.check(is_server_owner)
async def logchannel(ctx, channel = None):
    if channel == None:
        embed = discord.Embed(title='', color=bad,description=f'<:deny:903751730880213062> specify log channel **channel id** or **channel mention**')
        await ctx.send(embed=embed)
    else:
        channel_id = channel.split('<#')[1].split('>')[0]
        db.update_one({ "guild_id": ctx.guild.id }, { "$set": { "log": channel_id}})
        embed = discord.Embed(title='', color=good, description=f'<:approve:906649360396353567> log channel updated to: **{channel.mention}')
        await ctx.send(embed=embed)

@bot.command()
@blacklist_check()
async def presence(ctx, user: discord.User = None):
        if user == None:
            user = ctx.author

        status = user.status
        if status == discord.Status.offline:
            status_location = "undefined"
        elif user.mobile_status != discord.Status.offline:
            status_location = "mobile"
        elif user.web_status != discord.Status.offline:
            status_location = "web"
        elif user.desktop_status != discord.Status.offline:
            status_location = "desktop"
        else:
            status_location = "Not Applicable"
        embed=discord.Embed(description=f"💬 **{user.activity.name}**\n**presence**\n %s: `%s`" % (status_location, status), color=color)
        embed.set_author(name=f"{user}", icon_url=user.avatar_url)
        await ctx.send(embed=embed)

@bot.command()
@blacklist_check()
async def poll(ctx, *, message):
    e = discord.Embed(title=f"{message}", description=f"1️⃣ yes\n2️⃣ no", color=color)
    e.set_footer(text=f"started by {ctx.author}", icon_url=ctx.author.avatar_url)
    msg = await ctx.send(embed=e)
    await msg.add_reaction("1️⃣")
    await msg.add_reaction("2️⃣")







@bot.command()
async def whrtbiojrhgythi(ctx):
    await ctx.send(f'j')
@bot.command()
async def fiojgtohuo(ctx):
    await ctx.send(f'j')
@bot.command()
async def oieuhfiuhigtio(ctx):
    await ctx.send(f'j')
@bot.command()
async def oidfrhtig(ctx):
    await ctx.send(f'j')
@bot.command()
async def doifutghituh(ctx):
    await ctx.send(f'j')
@bot.command()
async def epodrjfigoit(ctx):
    await ctx.send(f'j')
@bot.command()
async def eoidjthgiurpo(ctx):
    await ctx.send(f'j')
@bot.command()
async def sriththoti(ctx):
    await ctx.send(f'j')
@bot.command()
async def iodhrtgohtu(ctx):
    await ctx.send(f'j')
@bot.command()
async def eoitohgtuhu(ctx):
    await ctx.send(f'j')
@bot.command()
async def uidhiuhtfituh(ctx):
    await ctx.send(f'j')
@bot.command()
async def sdiourhfitugho(ctx):
    await ctx.send(f'j')
@bot.command()
async def sdjrhfu(ctx):
    await ctx.send(f'j')
@bot.command()
async def shitbt(ctx):
    await ctx.send(f'j')
@bot.command()
async def whrsdoifrhtbiojrhgythi(ctx):
    await ctx.send(f'j')
@bot.command()
async def dejhfit(ctx):
    await ctx.send(f'j')
@bot.command()
async def sodijohfu(ctx):
    await ctx.send(f'j')

bot.run('OTE5Mjg2NDU4MTgxODk4MzAw.YbTmOw.IzY94yvAI7IzUT_BL1UGjbrdyA0')